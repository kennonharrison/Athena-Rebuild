#!/bin/bash
export HOME=/home/ubuntu
export NODE_ENV=production
export OPENCLAW_GATEWAY_TOKEN=<REDACTED>

# V8 heap cap
_MEM_LIMIT_BYTES=""
if [ -r /sys/fs/cgroup/memory.max ]; then
  _MM=$(cat /sys/fs/cgroup/memory.max 2>/dev/null)
  [ "$_MM" != "max" ] && _MEM_LIMIT_BYTES="$_MM"
fi
if [ -z "$_MEM_LIMIT_BYTES" ] && [ -r /sys/fs/cgroup/memory/memory.limit_in_bytes ]; then
  _MM=$(cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>/dev/null)
  [ -n "$_MM" ] && [ "$_MM" -lt 1125899906842624 ] 2>/dev/null && _MEM_LIMIT_BYTES="$_MM"
fi
if [ -z "$_MEM_LIMIT_BYTES" ]; then
  _MEM_TOTAL_KB=$(grep -m1 MemTotal /proc/meminfo 2>/dev/null | tr -dc 0-9)
  [ -n "$_MEM_TOTAL_KB" ] && _MEM_LIMIT_BYTES=$(( _MEM_TOTAL_KB * 1024 ))
fi
if [ -n "$_MEM_LIMIT_BYTES" ] && [ "$_MEM_LIMIT_BYTES" -gt 0 ] 2>/dev/null; then
  _HEAP_MB=$(( _MEM_LIMIT_BYTES / 1048576 * 75 / 100 ))
  if [ "$_HEAP_MB" -ge 512 ]; then
    export NODE_OPTIONS="--max-old-space-size=$_HEAP_MB"
    echo "[start-gateway] node old-space cap: $_HEAP_MB MB"
  fi
fi

# Kill any existing processes
pkill -9 -f "supervisord.*supervisord-openclaw" 2>/dev/null || true
pkill -9 -f "gw-watchdog" 2>/dev/null || true
sleep 0.5
pkill -9 -f "openclaw gateway" 2>/dev/null || true
pkill -9 -f "openclaw-gateway" 2>/dev/null || true
pkill -9 -f "socat.*18789" 2>/dev/null || true

rm -f /tmp/openclaw-*/gateway.*.lock 2>/dev/null

for _i in 1 2 3 4 5; do
  echo > /dev/tcp/127.0.0.1/18789 2>/dev/null || break
  sleep 0.5
done

mkdir -p /home/ubuntu/.openclaw/supervisor-include

# Use alternative paths under home dir to avoid root-owned /tmp files
CONF_DIR=/home/ubuntu/.openclaw/supervisor-tmp
mkdir -p "$CONF_DIR"
rm -f "$CONF_DIR/supervisord-openclaw.pid" "$CONF_DIR/openclaw-supervisor.sock" 2>/dev/null

OPENCLAW_BIN=/usr/bin/openclaw
[ -x "$OPENCLAW_BIN" ] || OPENCLAW_BIN=/usr/local/bin/openclaw
_OPENCLAW_VER=$(node -e "var p=['/usr/lib/node_modules/openclaw/package.json','/usr/local/lib/node_modules/openclaw/package.json'];for(var i=0;i<p.length;i++){try{process.stdout.write(require(p[i]).version);process.exit(0);}catch(e){}}process.stdout.write('unknown');" 2>/dev/null || echo "unknown")

mkdir -p /tmp/openclaw

cat > "$CONF_DIR/supervisord-openclaw.conf" << SUPEOF
[supervisord]
nodaemon=true
logfile=/home/ubuntu/.openclaw/supervisord.log
pidfile=$CONF_DIR/supervisord-openclaw.pid
loglevel=warn
environment=HOME="/home/ubuntu",PATH="/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"

[unix_http_server]
file=$CONF_DIR/openclaw-supervisor.sock
chmod=0770

[rpcinterface:supervisor]
supervisor.rpcinterface_factory = supervisor.rpcinterface:make_main_rpcinterface

[supervisorctl]
serverurl=unix://$CONF_DIR/openclaw-supervisor.sock

[include]
files = /home/ubuntu/.openclaw/supervisor-include/*.conf

[program:openclaw-gateway]
command=$OPENCLAW_BIN gateway --allow-unconfigured
directory=/tmp/openclaw
environment=HOME="/home/ubuntu",PATH="/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin",OPENCLAW_VERSION="$_OPENCLAW_VER",OPENCLAW_NO_RESPAWN="1"
autostart=true
autorestart=true
startretries=2147483647
startsecs=5
stdout_logfile=/home/ubuntu/.openclaw/supervisord.log
stderr_logfile=/home/ubuntu/.openclaw/supervisord.log
redirect_stderr=true
stopwaitsecs=10
killasgroup=true
stopasgroup=true
SUPEOF

exec supervisord -c "$CONF_DIR/supervisord-openclaw.conf"
