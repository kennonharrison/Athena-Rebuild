# Recovery Protocol

## Purpose
This file defines the explicit recovery phrases and procedures for restoring Athena's working state from a known-good workspace backup if future agent changes, memory drift, or context fragmentation degrade performance.

## Primary Recovery Phrase
`Re-anchor to Athena backup.`

## Meaning
When Kennon says `Re-anchor to Athena backup.`, it means:
1. Stop introducing new structural assumptions.
2. Treat the current working state as potentially drifted or partially unreliable.
3. Read the authoritative backup snapshot at:
   - `backups/athena-state-2026-05-04/`
4. Re-read, in order:
   - `backups/athena-state-2026-05-04/README.md`
   - `backups/athena-state-2026-05-04/STATE-SUMMARY.md`
   - files in `backups/athena-state-2026-05-04/core/`
   - relevant recent files in `backups/athena-state-2026-05-04/memory/`
   - relevant artifacts in `backups/athena-state-2026-05-04/exports/`
5. Treat that snapshot as the authoritative working baseline.
6. Resume work from that baseline while preserving any clearly user-approved work created afterward unless Kennon explicitly says to disregard it.

## Escalated Recovery Phrase
`Hard re-anchor to Athena backup.`

## Meaning
When Kennon says `Hard re-anchor to Athena backup.`, it means:
1. Follow the full re-anchor procedure above.
2. Assume recent drift may be substantial.
3. Prioritize the backup state over recent inferred context unless Kennon explicitly says that later work should override it.
4. Ask as little as possible; restore baseline first, then reconcile any newer work.

## Important Distinction
This protocol restores the best recoverable workspace-defined working state. It does not restore hidden runtime internals or non-workspace system state.

## Current Authoritative Backup
- `backups/athena-state-2026-05-04/`

## Notes
- Recovery is conceptual and operational, not destructive by default.
- The goal is to restore orientation, continuity, tone, open loops, and active strategic state.
- Do not blindly delete newer work during recovery. Re-anchor first, then reconcile.
