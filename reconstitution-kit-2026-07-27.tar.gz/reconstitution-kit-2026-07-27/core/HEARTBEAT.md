# HEARTBEAT.md

## Morning Briefing (7 AM ET / 11:00 UTC)
**Run the full briefing when heartbeat fires at or after 7 AM ET / 11:00 UTC, once per day.**
- Check current time first. If before 11:00 UTC, reply HEARTBEAT_OK.
- If at/after 11:00 UTC AND `briefingSent` in heartbeat-state.json is not today's date (YYYY-MM-DD), run the full briefing.
- If briefing already sent today (matching date in heartbeat-state.json), reply HEARTBEAT_OK.
- Execute every step below when running:
  1. Read research/README.md for categories
  2. Run 3-5 web searches on Work categories (ed tech, workforce dev, AI in education, policy)
  2a. Run 1-2 searches on latest news from OpenAI, Google Gemini, and Anthropic specifically (model releases, product updates, partnerships, policy positions). Include a dedicated "AI Lab News" section in the briefing summary.
  2b. Run 1-2 searches on Norwood Creek / Regen Ag Intel (daily, not just Sundays):
      - Search terms: regenerative agriculture + Virginia OR Mid-Atlantic OR East Coast + university OR community college OR state government OR grant OR permaculture OR agroforestry OR "community development" OR "food systems" OR "local food"
      - Include a "Norwood Creek / Regen Ag Intel" section in the briefing with 3-5 bullets
      - Flag people who could be network contacts, grants Norwood could apply for, events to attend
      - ONLY include funding that a 140-acre heritage farm in Virginia could plausibly access
  3. If Sunday, also run full Norwood categories (grants, competitive landscape)
  4. Check Gmail inbox: `node gmail/gmail.js inbox "is:inbox is:unread" 10`
  4a. Check Google Calendar for next 48h. Use the **aggregator** so the work import calendar is included:
      - `node gmail/calendar.js week-all`  (combines primary + work import calendar, sorted)
      - If only the personal calendar is needed for a specific check: `node gmail/calendar.js week`
      - If only the work calendar is needed: `node gmail/calendar.js week n37l3eq42bavjgrtfb937sb8fkt2bg8s@import.calendar.google.com`
      - Filter out summaries starting with "Canceled:" and recurring "Submit your Time Sheets" before reporting.
  4b. Flag any events in the next 24h in the briefing
  4c. Identify **high-priority meetings** for tomorrow using these criteria:
      - External partners (Khan Academy, Anthropic, CompTIA, Zoom, GlobalMindED, etc.)
      - Senior leadership meetings
      - One-off meetings (not recurring standups)
      - Anything tied to Certify.ai, Khan University, American Skills Project, Norwood
      - Include time, title, who's involved, what project it connects to, any prep needed
  4d. **If Sunday evening (ET 9-11 PM):** Send a **week-ahead preview** to Telegram highlighting the most important meetings for the coming week (Mon-Fri). Keep it to 10-15 lines max.
  4e. Pull the latest Chronicle of Higher Education newsletter: `node gmail/gmail.js inbox "from:newsletter@newsletter.chronicle.com" 1`
      - Read the full message with `node gmail/gmail.js read <messageId>`
      - Include a "Chronicle" section in the briefing with 3-5 key headlines/items, noting anything relevant to ETS, workforce, AI in education, or higher ed policy
  5. Flag important/actionable emails in briefing
  5a. **Priority senders** -- always flag and summarize in detail:
      - Adams Sutphin (Norwood contractor/legal)
      - Sadler and Whitehead (Norwood)
      - David Lionberger (Norwood)
      - becpas.com / BEC (Norwood)
      - Michael Chasen (ETS/Certify.ai project)
      - Eric Bendfeldt / ebendfel@vt.edu (Norwood regen ag, VT Extension)
      - John Few / johnf93@vt.edu (VCE Powhatan, Extension Agent)
      - Agatha Brinkley / commongrainalliance.org (Common Grain Alliance)
      - Pete Sisti / grgrains.com (Grassland Farm, Powhatan)
      - Anthony Beery / beeryfarms.com (Beery Farms)
      - Rob Waring / brandonfarms3012 (Brandon Farms)
      - C.J. Isbell / keenbellfarm (Keenbell Farm)
      - J.B. Daniel / va.usda.gov (USDA)
      - Matt Royer (Penn State)
  6. Check for credit card transaction alert emails: `node gmail/gmail.js inbox "from:chase OR from:citi OR from:bankofamerica OR from:boa OR from:venmo subject:(transaction OR purchase OR charge OR sent OR paid OR alert)" 10`
  7. Log any transactions to research/expenses/YYYY-MM-DD.csv
  7a. **If Sunday:** Generate weekly expense summary from all research/expenses/ CSVs for the past 7 days
  7b. **If Sunday:** Update research/expenses/budget-tracking-YYYY-MM.md with:
      - Week number and date range
      - Total spent vs weekly target ($1,615)
      - Running monthly total vs monthly budget ($7,000)
      - Days remaining and pace analysis
      - Category breakdown and top merchants
      - Include budget status in briefing (on track / over / under)
  8. Write research findings to research/findings/YYYY-MM-DD.md
  9. Update research/search-usage.json with search count
  9a. **KTI / Project Kite Monitoring:** Search for news coverage, social media reaction, opinion pieces, and competitor responses related to Khan TED Institute (KTI), Khan Academy degree program, or ETS + Khan Academy + TED partnership. Include a dedicated "KTI Watch" section in the briefing with:
      - New articles or press coverage since last briefing
      - Notable social media reactions (positive, negative, skeptical)
      - Competitor or analyst commentary
      - Anything Kennon should respond to or be aware of
      - Flag if coverage mentions ETS specifically and how it's framed
  10. Send concise summary to Kennon via Telegram: top 3-5 research items, important emails, any expenses logged, action items, time-sensitive items
  11. Log completion to memory/heartbeat-state.json: set `lastBriefing` to current UTC timestamp and `briefingSent` to today's date (YYYY-MM-DD). This is for logging only -- never use it to skip future runs.
