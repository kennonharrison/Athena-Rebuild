# RADAR — Weekly Signal Scan
_Run: 2026-06-14 04:00 UTC (Sun). Window: last ~3 weeks (cadence break — first run since 2026-05-24). Prior run: 2026-05-24._

Scope: ETS, KTI / Khan TED Institute, Certify.ai, workforce/AI policy, Norwood-relevant grants, partner/market signals. Noise filtered. Only items that could change priorities, positioning, or deadlines are listed.

**Cadence note:** The weekly RADAR cron did not fire on 2026-05-31, 2026-06-07, or 2026-06-14 prior to this manual trigger. This is the first weekly scan in 21 days. Continuity has been carried by daily logs and OPEN-LOOPS, but the radar-grade synthesis lapsed. Worth confirming the radar cron is wired to the same scheduler that runs the librarian (`dbeee0c9` ran clean 5/31).

---

## 1. Workforce Pell — federal switch is on, state switches are mixed; VA status unverified

The headline carry from 5/24 played out roughly as predicted, with one important adjustment to the Channel B/C lighthouse logic.

- **Effective date is now confirmed at July 20, 2026** (with optional July 1 early implementation at institution discretion). Final rule cite: Federal Register Vol 91 No 96, May 19, 2026, "Accountability in Higher Education and Access Through Demand-Driven Workforce Pell."
- **State readiness is highly uneven.** Per the Opportunity Data tracker (last updated 2026-06-06): only **5 jurisdictions have public application guidance issued and accepting submissions**; **29 have a named lead agency or working group**; **17 have no verifiable public action**. Implementation now sits with each governor in consultation with state workforce boards before institutions can submit programs to USED.
- **Lighthouse states — fresh state-level signal worth incorporating into the matrix:**
  - **Texas (TX)** extended its Eligibility Certification Form deadline to **June 19, 2026** — currently the most active near-term state milestone.
  - **Michigan (MI)** institutional submission deadline **June 15, 2026**. Not a Certify.ai lighthouse but a useful precedent for how an early-mover state actually runs the pipeline.
  - **North Carolina (NC)** approved state Workforce Pell policy via NCWorks Commission on May 14 — locks NC's place in the lighthouse matrix.
  - **California (CA)** AB 1534 passed Assembly May 21, in Senate Education and Labor as of June 3.
  - **New Hampshire (NH)** HB 1774 enrolled, awaiting Governor Ayotte signature.
  - **Maryland (MD)** SB 0509 took effect June 1.
  - **Idaho (ID)** WDC began accepting pilot program applications June 1.
  - **Minnesota (MN)** provider portal opened June 1, applications due **June 30 noon**.
  - **Virginia (VA) — no public action verifiable in the tracker as of 6/6.** This is a meaningful signal. The lighthouse matrix has VA locked at top of the priority list (criterion: ETPL maturity + ETS/Kennon footprint + SBH precedent), but the state-side implementation pipeline is not visible. **Action owed:** confirm whether VA is actually in the 29-jurisdiction "named-lead" cohort or the 17-jurisdiction "no public action" cohort. If the latter, VA's lighthouse positioning is contingent on state activation, which is not happening on the federal effective-date timeline.
- **Accountability phase-in clarified:** transitional standard (70% completion + 70% any-employment) holds AY 2026-29; tighter "trained-occupation employment" standard begins AY 2029-30; Value-Added Earnings Test binds AY 2030-31. **Implication for Certify.ai pitch language:** the soft accountability window is wider than the 5/24 framing. "Workforce Pell-eligible pathway" is defensible through 2029 without leaning on outcome thresholds.
- **DOL SCC Round 6 closed 2026-05-20** ($65M for community colleges preparing Workforce-Pell-aligned programs). RADAR-flagged 5/17 and 5/24 as a Certify.ai partner-network crosswalk opportunity. **Window has now closed without a logged crosswalk pass.** Awards will land in the next 60-120 days; the partner-list will become a real asset for Channel A/B/C outreach. Worth a calendar reminder.

**Action this week:** confirm VA's actual state-approval status against the Opportunity Data tracker; revisit lighthouse matrix's VA-first ordering if VA has slipped; redline of WIOA v2 against final rule text is **still owed** from 5/23 flag (now 22 days post-flag, third RADAR cycle without movement).

## 2. Certify.ai — three weeks of motion in OPEN-LOOPS, but radar-grade external signals are quiet

The radar-grade story this cycle is mostly **internal motion captured in OPEN-LOOPS** (term sheet v2 → $8M/$40M PBC, Bridges WFSGD substantive reply, six pre-circulation gates, Strategic Anchor Tranche). Externally:

- **No new public competitor signal** in the Certify.ai problem space across the 21-day window. Coursera-Udemy quiet. Microsoft Credentials AI Challenge quiet. CompTIA quiet. No new "AI fluency cert" entrant flagged in any daily log.
- **Three federal grant signals worth a fresh look** (all surfaced or sharpened in the last 21 days):
  - **EDA $25M AI Upskill Accelerator Pilot Program** (NOFO posted May 11, Forbes 6/1, govmarketnews 6/1). 5-8 awards at $1M-$8M each, 60% federal cost share, 24-36 month performance, **employer-led sectoral partnership is a hard eligibility gate.** Stand-alone training providers are not competitive. **Direct read for Certify.ai:** the grant cannot be won by Certify.ai or any single CC; it can be won by an employer-led coalition where Certify.ai is the training partner. **Steven Bridges asked directly** in his 5/29-30 reply whether Kennon was pursuing EDA — likely this exact program. The Bridges question now has a coherent answer: WFSGD-led coalition with Certify.ai as training partner is the only structurally winnable shape.
  - **EDA's Public Works and Economic Adjustment Assistance (PWEAA) NOFO framework** is the administrative wrapper. Useful only if Certify.ai is in a coalition.
  - **NSF + DOL + USDA + SBA TechAccess: AI Ready America** (mentioned in Forbes 6/1). State AI literacy hubs + national convener + skill-development grants. Adjacent to the EDA program but with different eligibility. Worth one scoping pass to see if Certify.ai or KTI fits the "national convener" or "innovative AI skill development" tracks.
- **Action this week:** answer Bridges. The structural shape is now clear (WFSGD-led, Certify.ai as training partner, EDA AI Upskill Accelerator as the grant vehicle). This unblocks ~$3M-$8M of non-dilutive runway and gives the WIOA Channel A pitch a federal-money pressure release.

**Six pre-circulation gates and four lighthouse decisions remain unmoved** (per OPEN-LOOPS 5/31). The radar cannot accelerate them; flagging only that they are concentrating on a single Kennon-decision queue alongside the Bridges and Tom items.

## 3. KTI — press cycle stayed quiet; tone remains skeptical-curious; one new framing worth tracking

- **Coverage cadence:** Chronicle 5/18 + Higher Ed Leaders Substack 5/18 remain the canonical post-launch placements. **No new mainstream press across the 21-day window.** Daily logs 6/4 → 6/13 all confirm: no new hostile coverage, no social flare-ups, no critic search hits.
- **Two consumer-facing explainers** stabilized as the canonical reference layer:
  - **collegehelpguide.com** "Khan TED Institute: $10K AI Degree Explained" — explicitly notes not yet accredited, can't currently confer degrees, no Title IV aid; targets late 2026/2027 application launch. **ETS named in framing.** This is now the most-linked consumer explainer.
  - **learnworkecosystemlibrary.com** lists KTI as "Bachelor's Degree in Applied AI." Worth tracking as that framing spreads — "Applied AI" lands closer to Certify.ai's positioning than "AI-First College" does.
- **khanted.org is live** but minimal (Home / News / Privacy pages only; no degree program detail, no faculty roster, no application portal). News page is empty. **The site is structural placeholder, not an active marketing surface.** Implication: KTI's public-facing posture is still gated behind upcoming announcements; press cadence gap is a deliberate or capacity-constrained pause, not a positioning failure.
- **KTI Decision Workshop Day Two happened Fri 6/12** in DC + virtual (highest-signal meeting of the week per Kennon's flagging). Outcome not logged in 6/12 daily as of this scan. Worth confirming and feeding into next radar.
- **JA Worldwide partnership (5/19) — 26 days carry without movement.** Five open questions still on the table per `memory/topics/khan-university.md` (IP/rev split; required vs optional specialization; MOU vs early exploration; fundraise mechanics; brand harmonization across Khan / TED / LF / JA). **Flag escalating:** the longer JA sits without a formal posture, the higher the risk that the third credential franchise gets announced unilaterally or contradicts an existing ecosystem-partner constraint.
- **Action this week:** Kennon log of 6/12 KTI Decision Workshop outcome. JA Worldwide formal posture decision. Sal Khan 5/18 call outcome **still undocumented** (now 27 days; was 13 days at 5/24 RADAR; was 6 days at 5/24 OPEN-LOOPS). Continuity gap is escalating, not closing.

## 4. AI lab market — three structural moves in 14 days that touch ETS, KTI, and Microsoft conversations

This is the heaviest section of the cycle. Three labs made structural moves in the last two weeks that ripple into Kennon's partner conversations.

- **OpenAI confidential S-1 filed 2026-06-08** ("Confidential submission of draft S-1 to the SEC" + "Built to benefit everyone: our plan" + OpenAI Economic Research Exchange announce, all same day). **OpenAI is now structurally on the IPO path.** Pairs with Anthropic's June 1 confidential IPO filing flagged in 6/10 findings. **Both frontier labs are moving toward public markets in parallel.**
  - Implication for Kennon: any OpenAI / Microsoft / Anthropic partnership conversation now sits inside an IPO-window context. Public-market disclosure pressure changes how partners can structure deals, what gets announced, and what gets quietly extended. The **Microsoft / KTI conversation Tue 6/16 1pm ET** lands inside this window — the IPO context is real Kennon-pocket framing.
- **OpenAI to acquire Ona 2026-06-11** (per OpenAI news page). Ona is a workforce/applied-AI play (not yet fully captured in our internal notes). Worth a one-pass scrape to confirm the company's positioning before the 6/16 KTI/Microsoft discussion. **If Ona is in the AI-fluency-cert or upskilling space, the Certify.ai competitive frame just shifted.**
- **OpenAI Academy expanded 2026-06-12** ("New OpenAI Academy courses for the next era of work"). OpenAI is **moving directly into the workforce-AI-training surface** that Certify.ai's Channel A and KTI's degree program both occupy. This is the first frontier-lab move into the credentialing-adjacent space since the May Coursera-Udemy noise. Not yet a degree-conferring play, but the trajectory is on the same vector.
- **Anthropic export control (Fable 5 / Mythos 5) 2026-06-12.** Per Anthropic's news page: "The US government has issued an export control directive to suspend all access to Fable 5 and Mythos 5." This is the lead announcement on the page. **First time a frontier lab has had its model export-restricted by the US government.** Pairs with Anthropic's earlier Pentagon-classified-AI-consortium exclusion (5/18). The "Anthropic = safety-first / non-defense" brand is now being shaped externally, not just internally. Worth Kennon having on hand if Anthropic comes up in any KTI / ETS / partner conversation.
- **Anthropic Claude Fable 5 / Mythos 5 launched 2026-06-09** per 6/13 daily log: "~10pt jump on long-running analytics over Opus." Frontier capability is moving up another step three days before the export-control suspension. The juxtaposition — "best model + government suspension on the same model in 72 hours" — is the cleanest public signal yet of frontier-lab governance friction.
- **Coursera-Udemy** quiet across the 21-day window. Cursor's $60B financing and EU AI Act enforcement remain background context, not Kennon-decision items.
- **Action this week:** scoping pass on Ona before 6/16 Microsoft/KTI discussion. Anthropic export-control framing is Kennon-pocket-talking-point for any KTI partnership conversation. The OpenAI-S-1 + Anthropic-IPO + Ona + OpenAI Academy stack reframes the differentiation pitch for KTI: degree-granting + accreditation + Khan pedagogy + ETS psychometrics + JA entrepreneurship cert is **the only stack that doesn't sit downstream of an IPO-disclosure cycle.**

## 5. Hot near-term replies and decisions owed by Kennon — escalating staleness

Pulling forward from OPEN-LOOPS only the items that have decayed past acceptable thresholds:

- **Steven Bridges (Workforce Solutions Greater Dallas)** — substantive concept-note reply with two specific questions on 5/29-30. **Now 15-16 days without recorded outbound.** Hottest inbound of the cycle. **EDA AI Upskill Accelerator answer is now structurally clean** (see §2).
- **Bill West / KaWest Partners** — replied positive 5/21. **Now 24 days without follow-up.** This was on the 5/24 RADAR as "10 days post-reply, going stale fast." It is now genuinely stale. Either reach out this week or accept the relationship will need a reset.
- **Climate-Smart Ag VA application** — deadline **2026-06-15 (tomorrow)**. Flagged in every daily log 6/5 → 6/13. **No go/no-go decision logged.** Same posture as VTC America 250 in the 5/24 RADAR (which closed without a decision). **One more daily-log cycle and this becomes the second Norwood grant in 30 days that closed without an explicit Kennon call.**
- **Bendfeldt outreach** — now **31 consecutive days** without sending (was 17 at 5/24 librarian). Carry-forward in every daily log since 5/14. **Either send or formally park** — the radar has flagged this five cycles running.
- **GLG / Meredith McGannon** — paid expert project, time-sensitive. Surfaced 6/4. **10 days carry without decision.**
- **JA Worldwide formal posture** — 26 days carry; risk of unilateral announce or ecosystem conflict (see §3).

These are RADAR-grade because they are partner/market signals with decay timers. The pattern across them is consistent: the inbound queue is healthy; the outbound queue is the bottleneck.

## 6. ETS Rosedale — quiet, status quo

- No new municipal-record reporting on Lawrence Township rezoning across the 21-day window. No D&R Greenway Land Trust update.
- **Zero priority-sender mail from any ETS-side party** (per daily logs 6/4 → 6/13: Adams Sutphin / Sadler Whitehead / Lionberger / BEC / Chasen / Bendfeldt / Few / Brinkley / Sisti / Beery / Waring / Isbell / JB Daniel / Royer all silent for the entire window).
- **Why still on radar:** the capital-rationalization narrative continues to underpin the case for ETS taking the $2M co-lead seat in Certify.ai. Still no new evidence either way.
- **Action:** continue monitoring. No move required.

## 7. Norwood — grants and partners

Three meaningful changes since 5/24:

- **AFT Regenerate Virginia 2026 — confirmed open** with $55K Healthy Soils + $25K Farm Vitality. Daily logs 6/4, 6/5, 6/6, 6/7, 6/9, 6/10, 6/11, 6/12, 6/13 all reconfirm. **Direct fit for Norwood** (140-acre VA heritage farm, regenerative transition + diversification narrative). **Bendfeldt outreach is the natural opener and remains 31 days unsent.** This is the single most actionable Norwood item on the radar, with no external deadline pressure but a partner-network cost to delay.
- **Climate-Smart Agriculture VA General Program — deadline 2026-06-15 (~24 hours).** Surfaced 6/5. Flagged in every daily log since. **No go/no-go logged.** Time-sensitive as of this scan.
- **Conservation Innovation Fund Regenerative Mid-Atlantic Market Program** — surfaced via VT Beginning Farmer 12/2025 newsblast (per 6/9 findings). **Cohort signal worth tracking.** Norwood-relevant if cohort entry opens later in 2026.
- **Catalyzing Agroforestry Grant Program (CAGP) + ARKx** — surfaced 6/10 via AFT mid-Atlantic grant hub. Funded by Edwards Mother Earth Foundation + Southeast SARE with VT Agroforestry partners. **Plausible Norwood fit.** Worth direct outreach (cf. Bendfeldt).
- **VTC America 250** — closed 5/28 with no go/no-go logged. Mark as "passed without action" per 5/31 OPEN-LOOPS recommendation.
- **DOL SCC Round 6** — closed 5/20 with no Certify.ai-side crosswalk performed (see §1). Same outcome as VTC America 250: closed without a call.
- **April freeze damage assessment** — no USDA disaster declaration for Mid-Atlantic as of 6/13 daily log. Carry-forward unchanged.
- **Virginia Historic Rehabilitation Tax Credit** — Part 1/2/3 status for current Norwood phase still unconfirmed. Highest-dollar program. No change.

**Pattern worth naming:** of the seven Norwood-relevant grants/programs surfaced in the last six weeks (VTC America 250, DOL SCC Round 6, AFT Regenerate VA, Farm Vitality, Climate-Smart Ag VA, EDA AI Upskill, NRCS RCPP FY2026), **two have closed without a logged decision and one closes tomorrow.** The Norwood grant pipeline has a triage problem, not a discovery problem.

## 8. Infrastructure / methodology

- **web_search degraded across the entire 21-day window.** SearXNG (Brave/Perplexity) "base URL not configured" on most queries. DuckDuckGo intermittent (single provider; freshness flag unsupported by the kimi fallback). Direct `web_fetch` against publishers (ed.gov, Federal Register, openai.com/news, anthropic.com/news, opportunitydata.org, farmland.org) carried this RADAR's external pass. **Net effect:** confidence on internal-thread signals is high; confidence on "did I miss a press hit" is medium-low. **Now broken across five consecutive radar/librarian cycles.** Config fix is meaningfully overdue.
- **RADAR cron itself did not fire** on 5/31, 6/7, or 6/14 prior to this manual trigger. Worth confirming the radar cron is wired to the same scheduler that runs the librarian (`dbeee0c9` ran clean 5/31).
- **OpenClaw model wave:** Anthropic Fable 5 / Mythos 5 (6/9), OpenAI Codex updates, Google Gemini 3.5 wave continue rippling. Nothing yet displaces the current `myclaw/claude-opus-4.7` default for Athena's work.

---

## What changed vs. last RADAR (one-screen answer)

1. **Material:** Workforce Pell **state-readiness picture clarified.** 5 jurisdictions live, 29 in-progress, 17 with no public action. **VA is unverified.** The lighthouse matrix's VA-first ordering needs a state-side check before next CC partner conversation.
2. **Material:** **EDA AI Upskill Accelerator NOFO** (May 11, $25M, 5-8 awards $1M-$8M, 60% cost share, employer-led sectoral partnership required). This is **the structural answer to Bridges' "are you pursuing EDA" question** and unblocks $3M-$8M of non-dilutive runway via a WFSGD-led coalition with Certify.ai as training partner.
3. **Material:** **OpenAI confidential S-1 filed 6/8** + **Anthropic confidential IPO filing 6/1.** Both frontier labs are simultaneously on the IPO path. This reframes the Microsoft/KTI conversation 6/16 and any frontier-lab partnership posture.
4. **Material:** **OpenAI to acquire Ona 6/11** + **OpenAI Academy expansion 6/12.** OpenAI is moving directly into the workforce-AI-training surface. Scoping pass owed before 6/16.
5. **Material:** **Anthropic Fable 5 / Mythos 5 launched 6/9, US export control 6/12.** First export-restricted frontier model. Pairs with Pentagon exclusion. Reinforces Anthropic's safety-brand positioning but introduces real access-risk for any partner depending on Anthropic infrastructure.
6. **Material (gap):** **Sal Khan 5/18 call outcome still undocumented** — now **27 days carry**. Was 13 days at 5/24 RADAR. Continuity gap is escalating.
7. **Time-sensitive:** **Climate-Smart Ag VA deadline tomorrow 6/15.** No go/no-go logged in 9 consecutive daily logs.
8. **Time-sensitive:** **Bridges reply owed 15-16 days.** EDA answer is now structurally clean.
9. **Status quo:** ETS Rosedale quiet. Coursera-Udemy quiet. KTI press cycle quiet (skeptical-curious, no hostile coverage). JA Worldwide partnership unmoved (26 days).
10. **Methodology caveat:** RADAR cron missed 5/31, 6/7, 6/14. web_search broken across 5 cycles. External-press confidence medium-low.

---

_Next scan: next Sunday 04:00 UTC, **assuming the radar cron is wired correctly.** The single highest-leverage piece of work the radar can flag this week is **the Bridges reply with the EDA AI Upskill Accelerator coalition shape** — it answers the hottest inbound, unblocks the largest near-term federal grant fit for Certify.ai, and converts WFSGD from a pilot partner into a sectoral-coalition lead. Second-highest: confirm VA's actual Workforce-Pell state-readiness status before the next CC partner conversation._
