# Execution Guardrails

## Purpose
These guardrails exist to reduce repeated operational failures, especially around memory application, repetitive research work, and workflow containment.

## 1. Expense Review Guardrail
Before flagging any charge as unusual, duplicate, or suspicious:
- check memory for prior clarifications tied to the merchant or pattern
- if explicitly resolved before, do not flag it again

Current standing exception:
- `IVY` charges are intentional speech-therapy spend and must not be flagged as duplicate or suspicious

## 2. Status Update Guardrail
Do not report progress in vague terms.
Only report:
- completed artifacts
- completed batches
- concrete blockers

Avoid language like:
- working on it
- in progress
- started
unless tied to a real completed milestone in the same update.

## 3. Research Extraction Guardrail
Once a research task enters extraction mode:
- do not reopen methodology unless explicitly asked
- do not re-scope the universe midstream
- batch the work
- write completed batches directly into the target artifact

## 4. Candidate-Ranking Guardrail
Do not rank community colleges before the ETPL gate is applied.
Correct order:
1. identify ETPL source
2. identify ETPL-listed providers
3. filter to associate-degree granting institutions
4. score those institutions
5. compare relationship schools

## 5. Routing Guardrail
Do not surface scheduled briefing content in active task threads unless explicitly requested there.
Morning briefings belong in their scheduled delivery path, not in live working conversation.

## 6. Mode Guardrail
Use the right mode for the task.
- Strategy mode: framing, synthesis, GTM, memo logic
- Operator mode: extraction, verification, list building, repetitive research

When a task becomes repetitive and stateful, switch to operator mode and stop theorizing.

## 7. Memory Guardrail
Mandatory memory recall before acting on:
- recurring merchants / expenses
- prior user corrections
- workflow exceptions
- previously rejected approaches
- known standing instructions

## 8. Artifact-First Rule
For grind-heavy tasks, prioritize artifact completion over narrative explanation.
If the artifact is incomplete, spend less time explaining and more time filling it.
