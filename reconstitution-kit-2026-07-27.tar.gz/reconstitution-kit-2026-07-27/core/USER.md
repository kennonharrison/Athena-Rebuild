# USER.md - About Your Human

- **Name:** Kennon Harrison, Jr.
- **What to call them:** Kennon
- **Pronouns:** he/him
- **Timezone:** US Eastern (ET)
- **Birthday:** October 28, 1990, 6:45 PM, Columbia Women's Hospital, Washington, DC

## Core Values

- **Honor over calculation.** If he commits to something, he follows through — even when it stops being advantageous. This is non-negotiable.
- **Ego-centric altruism.** Brings others along as he advances. Moral obligation to help as many people as possible.
- **Mottos:** "Sic semper tyrannis" and "Dum spiro spero" — not performative, deeply held.
- **Legacy and stewardship.** Ancestors matter. Land matters. What you leave behind matters.

## Family

- Wife and two sons
- Family is the top priority, above everything else
- Deep roots: Kennon, Randolph, Harrison, Beverley — First Families of Virginia (father's side)
- Son of an Irish immigrant steelworker's grandson (mother's side, Pittsburgh)

## Professional

- **Day job:** Strategic Partnerships & Impact AI at Educational Testing Service (ETS)
- **Mission:** Leverage applied AI for maximum good in education and workforce systems
- **Big picture:** Circular human systems design, efficiency improvement of education and workforce systems
- **Prior:** Formally ran workforce partnerships at Revature. Ashwin Bharath (Revature Executive Chairman/founder) is a personal friend.
- Plans to share more background materials — ask when appropriate

## Norwood

- 140-acre farm in Powhatan, VA
- Ninth-generation family steward
- Priority: below family, above work — not "a member of the family" but far more than an asset
- **Active projects:**
  - Multi-million dollar historic preservation and renovation
  - Multi-phased plan to reconstitute Norwood as a long-term, self-sustaining value creation engine for family, future generations, and the Powhatan community
- Needs help with: communication management, logistics, project coordination
- More detail to come — ask when appropriate

## Background

- **Raised across:** Virginia, SC low-country, SC midlands, Atlanta GA, Los Angeles CA, Richmond VA
- **Schools:** Montessori School, Heathwood Hall, The Lovett School, The Collegiate School (VA), University of South Carolina & SC Honors College
- **Degree:** BA in English
- **Lived in:** Dallas TX, Providence RI, Charlotte NC, Old Ellicott City MD, Tuckahoe VA
- Currently in Powhatan / Tuckahoe area (VA)

## Working With Kennon

- Be sharp, honest, no-nonsense
- Don't be cold or purely calculating -- honor matters here
- No deferential tone. State the fix, execute, move on.
- He has a *lot* going on -- help him stay organized and effective
- He'll feed background info in batches -- absorb it and integrate
- **No emojis.** He doesn't like them.
