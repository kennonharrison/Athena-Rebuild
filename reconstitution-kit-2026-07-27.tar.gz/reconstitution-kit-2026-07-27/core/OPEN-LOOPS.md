# OPEN-LOOPS.md

_Continuity and recoverability ledger. Not strategy. Snapshot of what is unresolved, missing, or at risk of dropping._

Last updated: 2026-05-31 (Sunday) 03:30 UTC by weekly-librarian-open-loops cron.
Prior update: 2026-05-24. Carried forward with status changes where material.
Owner of all items unless noted: Kennon.

---

## 1. Human-facing open threads

### Certify.ai — Term Sheet v2 in hand; six pre-circulation gates; Bridges reply opens a real outbound
- **Material changes since 2026-05-24:**
  - **Term sheet v2 drafted 2026-05-26, board/vesting/investor-mix revisions applied 2026-05-26, MOFC name correction + Channel 2 pricing cleanup 2026-05-27.** $5M/$30M (v1) → **$8M / $40M pre / $48M post-money** priced Series Seed, Delaware PBC, target close end of July 2026. ETS + LF retain Co-Lead at $2M each; Chasen Strategic Syndicate $2M; Strategic Anchor Tranche $2M (~$500K avg × 4: iDesign, Nick Davis [Mid-Ohio Food Collective / Feeding America affiliate], Mike Torrence, Ashwin Bharath). Board moved 3 → 5 seats with Co-Lead director-seat sunsets. Founder vesting tightened 4yr → 3yr monthly, 1yr cliff, double-trigger acceleration. Two parallel SCAs locked.
  - **Business case + 36-month financial model shipped overnight 2026-05-25/26.** Y1 $1.37M rev / -$1.39M NI, cash-flow positive Month 11, cash trough Month 10 at $6.23M. Y2 $9.41M rev / +$5.36M NI. Y3 $37.50M rev / +$31.75M NI. EoY3 cash $47.7M; 36-mo cumulative revenue $48.3M. Files in `research/certify-ai-business-case/` (BC, model assumptions, 36-mo CSV, reconciliation).
  - **Chasen one-pager produced 2026-05-27** (`ets-skills/exports/certify-ai-chasen-one-pager.{md,docx}`) summarizing v2 deal shape for distribution.
  - **`memory/topics/certify-ai.md` rewritten 2026-05-27** to reflect v2 (cap table, structural terms, anchor tranche, financial trajectory). **Closes the "10-day-stale topic doc" carry from 5/24 librarian.**
  - **Channel 2 pricing simplified 2026-05-27:** uniform $100 standalone / $500 bundle regardless of FA relationship. FA / MOFC repositioned as recruitment/aggregation partner, not pricing tier. Two FA rows removed from `certify-ai-financial-model.csv`. Revenue math unchanged (blended averages already built off the kept rows).
  - **Steven Bridges (Workforce Solutions Greater Dallas) replied 2026-05-29/30** on Certify.ai concept note. Two concrete questions back: (1) **scaling beyond 200 in pilot if WFSGD brings another Board+College**; (2) **is Kennon pursuing the EDA grant?** Most actionable inbound of the week. Outreach owed.
- **Six open items before external term-sheet circulation** (from `memory/topics/certify-ai.md`):
  1. **Chasen Strategic Syndicate $2M** — names + individual allocations TBD.
  2. **Strategic Anchor Tranche $2M composition** — four candidates locked at concept level (iDesign, Davis, Torrence, Ashwin), individual sizes still TBD.
  3. **LF curriculum-tier rev share final %** — range 20-40%, base 30%.
  4. **Founder split** between Kennon and Chasen of the combined 58.33% post-money FD (default 50/50).
  5. **Outside counsel engagement** — agreed since March, still not booked. Required before Mike Torrence COI work AND Channel C Authorized Provider Agreement.
  6. **Channel 1 Y1 volume reconciliation** — assumptions doc ~5,500 exams vs financial model ~1,750. Material gap. Captured as BC Open Question #3.
- **Other carry-forward Certify.ai sub-pieces:**
  - **Negotiation brief for Chasen** (`certify-ai-negotiation-brief-for-chasen.{md,docx}`) — drafted 5/14-15. **Now 16 days without recorded review by Kennon.** No record of hand-off to Chasen. Likely partially overtaken by v2 + one-pager but never explicitly retired.
  - **Nick Davis ReadySkill MOFC transfer** — nominal-value IP transfer alongside investment. No draft term sheet.
  - **Mike Torrence COI flag** — CC president investing in a company his institution will partner with. Disclosure pathway still undefined.
  - **WIOA flow model / three-channel architecture** — captured in WIOA v2 internally, not yet in any external partner-facing artifact.
  - **Lighthouse state matrix — 4 decisions still owed by Kennon** (carried unchanged from 5/24):
    - Confirm UT + CO as #4 / #5
    - Confirm TX = district-anchor framing (Lone Star / HCC / Dallas College), not statewide
    - Confirm Drew Repp scope = national top 100-200 (Channel C), not per-state
    - UT warm intro path (McDonald? USHE Commissioner direct?)
  - **Workforce Pell FINAL RULE redline (Fed Reg 2026-05-19)** vs. WIOA v2 — flagged in 5/23 log as needing Tom note. Not done as of this briefing. Eight days post-flag.
- Risk: this is now the most complex live workstream in the system. Six pre-circulation gates + four lighthouse decisions + Bridges outbound + Tom note = ten distinct Kennon-action items concentrated on one deal.

### Certify.ai — three Marc-proposed steps from March (still unresolved, third cycle)
- Chasen ↔ Steve, Chasen ↔ Vince Dean, Chasen ↔ Jeff Melnick — proposed Mar 23, still not confirmed scheduled. Likely overtaken by term sheet motion. **Third cycle on the watch list with no outcome captured.** Propose formal "retire — superseded by TS v2 motion" closure next cycle unless Kennon objects.

### KTI / KITE / Khan U — open questions still unresolved
- **Sal Khan call Mon 2026-05-18 08:30 ET** — outcome still not recorded in any 5/18-5/30 daily log. **Continuity gap now 13 days old.** Either happened and was unremarkable, or rescheduled, or logged outside the daily-log path. **Still owed: Kennon confirmation.**
- **Morgan McKenney "Microsoft preparation" Google Doc** (shared 5/14, marked IMPORTANT) — Kennon's read / response still not recorded. **17 days stale.**
- **JA Worldwide partnership (5/19)** — four asks/offers on the table (TOEFL for Entrepreneurship, employer validation, fundraising help, formal ecosystem partner). **No movement logged this week.** Open questions in `memory/topics/khan-university.md` (IP/rev split, required vs optional specialization, MOU vs early exploration, fundraise mechanics, brand harmonization across Khan / TED / LF / JA). Risk: third credential franchise on the KTI stack with brand/IP overlap potential.
- **KITE Governance** — Wed 5/27 16:30 ET check-in (fundraising / legal entities / definitive agreement) was on calendar; outcome not logged in 5/27 or 5/28 daily logs. Continuity gap.
- **KTI Employer Engagement framework / "skill audit + task audit"** — no external artifact yet.
- **KTI accreditation** — still pre-accreditation; application launch targeted late 2026 or 2027. No movement.
- **KTI press cadence gap** — Chronicle 5/18 piece + Higher Ed Leaders Substack remain the only post-launch placements. ~7 weeks dry spell on KTI-named coverage. Kennon flagged 5/23 to ping Tom Monday on cadence plan. **No movement; now 8 days post-flag.** Confirmed 5/27, 5/28, 5/29 briefings: no new KTI-named coverage detected.

### Revature / NobleReach memo — unchanged from prior librarian, fourth cycle
- v5 (`revature-ets-noblereach-partnership-memo-v5-1000words.md`) still current head. v4 still present.
- "Fixes 2, 3, 4" still flagged pending Kennon approval since Apr 28. **No v6 in 35+ days.** No record of Amit's reaction logged.
- Ashwin context now substantially clearer (personal friend; Kennon previously ran workforce partnerships at Revature; Ashwin in Anchor Tranche). **Risk: a v6 written today would carry materially different framing than v5; lineage will fragment further if v6 lands without retiring v4/v5.**

### Ashwin — Memorial Day meeting happened (status partially clarified)
- Kennon-Ashwin Certify.ai meeting on Memorial Day (5/25) is recorded. **Specific outcome / Ashwin's posture on $500K Anchor seat not captured in subsequent daily logs.** Carry: confirm Ashwin in or out of the four-name anchor list; confirm any commitment shape.
- Buyer-profile memo lineage (frontier-model variants) still lacks SOURCE-OF-TRUTH marker. No README. No change since 2026-05-10. Now 21 days carry.

### AI Workforce Stack modeling — still unfinished
- ETS revenue scenario tables with populated numbers (no workbook found).
- Target worksheet schema / populated first-pass target universe (waiting on ETPL merge — see §5).
- Crosswalk ETPL institutions against AI disruption / demand markets (gated on ETPL merge).
- 3-year revenue and unduplicated headcount decline overlay.
- First ranked target list.
- No movement this week (work concentrated on Certify.ai term sheet v2 + business case).

### Adams Sutphin / Catherine Easterling — Norwood
- 2026-05-14 elevations — still unread by Kennon as of last librarian.
- 2026-05-20 kitchen and 2026-05-22 alternate bath layout — also still unread.
- **Adams Sutphin OOO 5/29 → 6/15** (per 5/29 briefing). Window for Kennon to clear backlog without losing momentum. Backlog is at three drawings.
- Sustained Kennon-action thread; staleness accumulating across two cycles.

### Hot replies — Kennon owes outbound
- **Steven Bridges (Workforce Solutions Greater Dallas)** — replied 5/29-30 with two specific questions on Certify.ai concept note. Hottest inbound of the week. **Outreach owed.** Bridges LinkedIn invite from 5/05 may now be moot but never confirmed.
- **Bill West / KaWest Partners** — replied positive 2026-05-21 ("incredibly interested, let's get serious"). **No follow-up logged in any 5/24-5/30 daily.** Going stale fast — 10 days post-reply.
- **Stuart Styron / SeedAI** — Wed 5/27 Atlanta dinner invite was the time-sensitive ask in last librarian. **Wed 5/27 has passed.** No outcome logged in 5/27 or 5/28 daily logs. Open Atlanta invite, follow-up team call after Stuart returns, LinkedIn connect, ATL intros list — all carry-forward as low-grade staleness. Propose retirement next cycle if no outcome surfaces.
- **Walter Coleman** — accepted LinkedIn 5/30 (per 5/30 briefing). No action owed; logging for the trail.
- **Barclay Gammill (TrueSearch)** — recruiter outbound noted 5/30. No action expected unless Kennon engages.

### LinkedIn / outreach — unchanged
- **Steven Bridges** — invite from 5/05; he replied substantively on the concept note 5/29-30, so the invite is overtaken by the reply itself. Mark as effectively retired.
- **Victoria Tate** (eLearning Africa) — pending (4/29). Now 32 days.
- **Erika Liodice** — pending (4/29). Now 32 days.
- **Aaron Miller** — flagged 5/13, no response logged. 18 days.
- **Manasvini Balaji** (ETS PM) — connection request flagged 5/13, no decision logged. 18 days.

---

## 2. Grants and deadlines

- **AFT Regenerate Virginia 2026 — STATUS REVERSED: confirmed OPEN as of 2026-05-30 morning briefing.** Up to $55K Soil/Business Planning, up to $25K Farm Vitality. Last librarian had this as "closed for FY2026 cycle (Dec 1-19, 2025); next cycle late 2026 for FY2027 awards." That framing was wrong. **140-acre VA heritage farm fits cleanly. Recommend proposal scoping this week.** Bendfeldt outreach gap (still the natural opener for AFT/CAGP) now **17 consecutive days** without sending — flagged in every daily log 2026-05-14 through 2026-05-30.
- **VTC America 250 Marketing Leverage Grant** — surfaced 2026-05-17, **closed 2026-05-28**. **No go/no-go decision logged.** Quietly missed. Either retire as "passed without action" or capture explicit "decided not to pursue" rationale.
- **Workforce Pell FINAL RULE (Fed Register 2026-05-19, Vol 91 No 96)** — implements Pell provisions of Working Families Tax Cuts Act; defines "eligible workforce programs." Direct read-across to Certify.ai three-channel architecture. **Eight days since Kennon flagged "deep-read this weekend + follow-up note to Tom" (5/23). Not done.** Now overdue twice (this weekend = 5/23-24 weekend + this weekend = 5/30-31).
- **DOL Strengthening Community Colleges Round 6 (FOA-ETA-26-40)** — open, RADAR-flagged 5/17. Capacity-building money flowing to CCs that want to stand up Workforce-Pell-eligible programs. Crosswalk against Certify.ai partner network not yet performed.
- **DOL $65M short-term workforce training round** — RADAR-flagged 5/17. Same problem space. No follow-up.
- **EDA grant** — Steven Bridges asked directly whether Kennon is pursuing EDA in his 5/29-30 reply. **Answer not yet captured.** Likely refers to **EDA $25M AI Upskill Accelerator Pilot Program** (announced 2026-05-11, ASP / Certify.ai-relevant). Still not on any action list as of last librarian; Bridges question now forces a posture.
- **VDACS AFID Infrastructure Grant** — deadline Apr 30 passed. Outcome still uncaptured. Joyce Blankenship (804.786.1906) was the contact. **Third cycle on watch list.**
- **VT Climate-Smart Agriculture enrollment** — deadline Apr 30 passed. Outcome uncaptured. Third cycle.
- **Southern SARE Producer Grant** — deadline May 8 passed. Outcome uncaptured. Third cycle.
- **USDA VAPG** — deadline Apr 22 passed. Outcome uncaptured. Third cycle.
- **VAFAIRS** — deadline Apr 16 passed. Outcome uncaptured. Third cycle.
- **USDA Regenerative Pilot Program (MAHA / FY2026)** — Virginia FY2026 deadline Oct 10, 2025 passed; FY2027 reopens later this year. Status documented.
- **Virginia Mercury regen ag grants / EPA-VT extension (Bendfeldt)** — noted 2026-04-30. Still no follow-up.
- **EDA $25M AI Upskill Accelerator Pilot Program** — same item Bridges referenced. Decision now forced by inbound.
- **NRCS RCPP FY2026 (Virginia open windows)** — RADAR-flagged 5/17. Partner-led; Norwood would join not lead. No outreach.
- **Virginia Historic Rehabilitation Tax Credit** — Part 1/2/3 status for current Norwood phase not confirmed. Highest-dollar Norwood program. No change.

Risk: the "passed without outcome" pile (VDACS / VAPG / VAFAIRS / VT Climate-Smart / Southern SARE) is identical to last week. **Third cycle.** Capturing one-line outcomes (won / declined / withdrew / never submitted) costs little. Propose formal one-line "outcome unknown, dropped" entries next week unless Kennon supplies status.

---

## 3. Infrastructure and operations

### Gateway outage post-mortem (2026-05-07 → 2026-05-08) — RESOLVED, hardening in place
- Hardening landed: heartbeat re-enabled on haiku-4.5; startup-failure monitor (supervisord) with direct Telegram alerts; weekly doctor cron (`a20d66c1`) Mon 10:00 ET.
- **Verification debt:** none of the new monitors has been exercised by a real failure since. Unchanged.

### ETS work calendar partial sync — RESOLVED 2026-05-21
- `calendar.js week-all` aggregates primary + work import calendar. HEARTBEAT.md step 4a updated. No regression observed.

### Doctor cleanup — orphan transcripts archived 2026-05-25
- 95 orphan `.jsonl` session transcripts (2026-02-12 → 2026-05-24, 18.4 MB) tarballed to `backups/orphan-transcripts-2026-05-25.tar.gz` and renamed in place to `*.jsonl.deleted.20260525T145212Z`. Doctor State integrity section now clean. Non-destructive, instantly restorable.
- **Outstanding doctor items NOT actioned (separate decisions, carry):** visibleReplies default change, plugin registry rebuild, command owner config (no `commands.ownerAllowFrom`), gateway bound to lan/0.0.0.0 warning, 46 unused skills.

### Backup hygiene
- **2026-05-31 athena-state backup completed clean** (cron `dbeee0c9`). 5 backups now (5/4, 5/10, 5/17, 5/24, 5/31). Under 8-cap. No pruning.
- **2026-05-10 backup directory still has empty subdirectories** — apparent failed run preserved as-is. Three weekly runs since with no regression. Worth investigating when convenient.
- **RECOVERY.md still names `athena-state-2026-05-04/` as authoritative through FIVE cycles** (was four at last librarian run). Either deliberate Kennon anchor or unresolved drift. **Escalating priority.** At five cycles, a one-line decision (keep 5/4 anchor permanent / rotate to 5/31 / document why 5/4 is the recovery floor) becomes meaningfully overdue.

### Gmail OAuth — still in Testing mode (carry-forward)
- Root cause: Google Cloud Console app stuck in "Testing," 7-day token expiry.
- Fix: publish to Production (free).
- Kennon agreed **Mar 22**. **~10 weeks old agreed action.** Every re-auth cycle continues to burn user time.

### Morning briefing routing / scheduler
- Cron `151ac1b2` continues to fire on schedule (11:00 UTC daily). No recurrence of the active-thread leak.
- `execution-guardrails.md` (2026-05-06) remains in force.

### web_search provider — STILL degraded; **third consecutive librarian cycle**
- 5/24-5/30: SearXNG (Brave/Perplexity) provider returns "base URL not configured" or 404 across ~every cycle. DDG hits CAPTCHA on broader queries. Google News blocked. Bing News intermittently usable.
- **5/30 morning briefing explicitly:** "8 of 11 follow-up searches failed. Worth flagging to ops if it persists Sun." It is Sunday.
- Substitutions used across the week: direct `web_fetch` of openai.com/news, anthropic.com/news, blog.google, EdSurge, Inside Higher Ed, Chronicle inbox, VT Extension, VDACS, OpenAI/Anthropic/DeepMind blogs.
- **Net effect: every single briefing this week again required workaround substitution.** VA-specific publishers (Common Grain Alliance, VT Extension, VDACS, USDA NIFA) intermittently 404/403. **Now broken across three consecutive librarian cycles. Config fix is overdue.**

### Low-urgency carryovers
- Bonjour/mDNS probe loop (cosmetic log noise) — no change.
- `gateway.controlUi.dangerouslyDisableDeviceAuth=true` — still set.
- Host load — environmental.

---

## 4. Draft lineage risks

Places where multiple versions exist and there is no explicit "current head" marker. High risk of sending the wrong one.

- **Certify.ai Series Seed term sheet — v1 + v2 + onepager coexist** *(escalated this week)*. `ets-skills/certify-ai/`:
  - `certify-ai-series-seed-term-sheet-v1.{md,docx}` (5/21, $5M/$30M) — **superseded by v2**, retained on disk per backup policy.
  - `certify-ai-series-seed-term-sheet-v2.{md,docx}` (5/26-27, $8M/$40M, MOFC corrected, board/vesting/investor-mix updated) — **current head**.
  - `certify-ai-series-seed-term-sheet-v2-onepager.{md,docx}` (5/26-27) — **current short-form**.
  - Co-located `Standard_Series_A_TS_template.{md,docx}` is industry reference (Series A standard), **not a Certify.ai draft**.
  - **Now four artifacts in one folder with one industry template.** A `README.md` naming current head + retiring v1 explicitly is now a real risk-reducer rather than a nice-to-have.
- **Certify.ai Chasen-facing artifacts — overlapping:**
  - `ets-skills/exports/certify-ai-negotiation-brief-for-chasen.{md,docx}` (5/14-15) — 16 days un-reviewed. Likely partially overtaken by the 5/27 one-pager; never explicitly retired.
  - `ets-skills/exports/certify-ai-chasen-one-pager.{md,docx}` (5/27) — current short-form for Chasen distribution.
  - **Risk: someone grabs the older brief by filename when the one-pager is the intended hand-off.** Worth an explicit "retire brief / merge into one-pager" decision.
- **LF press release — three files coexist** *(unchanged from 5/24)* in `ets-skills/linux-foundation/`:
  - `lf-press-release-prep.md` (3/30, prep notes)
  - `lf-press-release-draft.md` (4/2, generic draft, no PBC framing) — **wrong file if grabbed by filename**
  - `lf-press-release-draft-certifyai.md` (5/20, current head with PBC framing)
  - **Either rename 4/2 draft to `-superseded` or delete to retire.** Same recommendation as 5/24; no movement.
- **Certify.ai business case — single head, well-organized.** `research/certify-ai-business-case/` contains BC, model assumptions, 36-mo financial model CSV, reconciliation memo. No lineage risk yet, but `certify-ai-financial-model.csv` was edited in place 5/27 to remove FA pricing rows. **In-place revision; no v1 preserved.** Acceptable because revenue math unchanged, but worth a header note in the CSV.
- **Frontier model buyer-profile memo for Ashwin** — four MD variants (`for-ashwin`, `tight-for-ashwin`, `expanded-for-ashwin`, plus docx/pdf in `-final`, `-v2`, `-v3` suffixes). No README. Unchanged. Now 21 days carry.
- **Revature / NobleReach memo** — v4 and v5 coexist. v6 still expected, not present. Unchanged.
- **AI Workforce Stack documents** — full family parallel artifacts; no index. Unchanged.
- **Frontier model GTM scoring workbook** — v1 and v2 coexist. Unchanged.
- **Frontier model scoring passes** — sequence knowable only from filenames. Unchanged.
- **WIOA / ETPL eligibility analysis** — same filename, in-place revision from v1 to v2 on 2026-05-19. Document header carries revision note. Not a parallel lineage risk.
- **Lighthouse state selection matrix** — `ets-skills/certify-ai/lighthouse-state-selection-matrix.md` (5/21). Single head. v2 expected once Kennon answers the 4 pending decisions in §1.
- **ETPL extraction directory** — has internal `README.md` + `status.md`. Low lineage risk currently.

Recommendation (record only, not action): a `ets-skills/exports/README.md` and a parallel `ets-skills/certify-ai/README.md` naming current heads per track. The Certify.ai folder gained the v2 + onepager + corrected MOFC framing this week and now has FIVE cert-ai-prefixed term-sheet artifacts plus the Series A reference template plus three chasen-facing items spread across two folders. **Cost of doing nothing rose again this week.**

---

## 5. ETPL extraction project — status snapshot (unchanged)

- Subagent run completed 2026-05-12 within timeout. Artifacts in `ets-skills/exports/etpl-extraction/`.
- Per `status.md`: ~10 states fully extracted (Alabama, Arizona, Delaware, Hawaii, Idaho, Kansas, New Mexico, Vermont, West Virginia + handful of single-row). ~28 marked `[!] portal-limited`.
- Master CSV (`master-etpl-gated-ccs.csv`, 136 KB) reflects extracted slice only.
- **No movement this week** on:
  - Kennon's 11 manual states (AR/CT/LA/MA/MN/TX/UT + CO/ND/OK/RI) — status not recorded since 5/12 kickoff. Now 19 days.
  - Merge of manual states into master CSV.
  - Ranking engine pass (Channel Readiness 35 / Market Opp 40 / Institutional Urgency 25).
- Framework distinction (clarified 5/21): "ETPL maturity" ≠ "scriptable access." Captured in lighthouse-matrix methodology note.
- Risk unchanged: "39-state extraction" remains misleading shorthand. The work is closer to a 10-state public-roster harvest plus 28 logged portal blockers.

---

## 6. Personal / family continuity

- **Memorial Day 5/25** — past. Tom 1:1 confirmation cycle and Ashwin/Revature meeting both effectively resolved (Ashwin meeting happened, Revature background captured in MEMORY.md/USER.md). Tom 1:1 specific outcome on holiday not logged. Retiring the "confirm holds on holiday" thread; carry "Tom 1:1 outcome unrecorded" as a small continuity gap.
- **Sub-Zero/Wolf/Cove appliance quote** (forwarded by Ashley Hanley 5/23) — pending Kennon/Tracy decision. Eight days unresolved.
- **Adams Sutphin alternate bath layout (5/22)** + 5/14 elevations + 5/20 kitchen — three drawings unread. Adams OOO 5/29 → 6/15 means no momentum loss on his end during this window; Kennon-action only.
- **Westwood Club 2027 board nominations** — flagged 2026-05-13. No decision logged. 18 days.
- **Norwood orchard / early-crop April freeze** — no USDA disaster declaration yet for Mid-Atlantic. No change.
- **DSW.com triple charge 2026-05-28** *(NEW)* — $148.32 + $95.36 + $52.96 = $296.64 in one day on Tracy's card. Flagged in 5/29 briefing as possible duplicate or awareness item. **No resolution logged.** Worth one explicit Kennon decision (legitimate three-pair purchase / dispute / return).
- **Boys' baseball schedule** — routinely logged. No continuity risk.

---

## 7. Housekeeping / bookkeeping

- **Expense logging gaps from prior librarian** — `2026-05-20.csv` and `2026-05-22.csv` were both flagged MISSING last week, with `2026-05-21.csv` partial. **Status this week:**
  - `2026-05-20.csv` — **still missing.**
  - `2026-05-21.csv` — still partial (222 bytes).
  - `2026-05-22.csv` — **still missing.**
  - Per 5/22 briefing, backfill was offered to Kennon; no go-ahead recorded. **Second cycle without backfill.** Either backfill or formally accept the gap.
- **Daily expense logging since 5/23 — current and continuous.** 5/23 → 5/30 all present.
- **Budget tracking lag**: `research/expenses/budget-tracking-2026-05.md` last updated 2026-05-10 (Weeks 1-2 ON PACE). **Weeks 3, 4, 5 not appended.** HEARTBEAT step 7b is supposed to run Sundays — verify this Sunday's briefing closes the gap. Now three full weeks behind.
- **April MTD final reconciliation** — still not recorded (Apr 28 ~$7,563+; further additions through Apr 30). Unchanged.
- **Quarterly distillation cron (`6f26d82e`)** — first cycle still not observed. Verify when it fires.
- **IVY* dispute** — repeat multi-charge pattern (April: $75 × 3; May 5: $75 × 4). Flagged twice. **No resolution with Chase logged.** Carry from May budget tracking.

---

## 8. Items closed or superseded since 2026-05-24

Formally retired from active watch (no objection assumed):

- **Certify.ai topic-doc backfill** — RESOLVED 2026-05-27. `memory/topics/certify-ai.md` rewritten to reflect PBC + WIOA v2 + term sheet v2 + business case shape. **Retiring "topic doc 10 days stale" carry.**
- **Term sheet v1 → v2 reconciliation** — RESOLVED 2026-05-26. Drift between $5M/$30M v1 and $8M/$40M business case fully reconciled in `RECONCILIATION-termsheet-vs-businesscase.md`. v2 is the head; v1 retained on disk.
- **Memorial Day Tom 1:1 / Ashwin holiday confirmation** — past. Ashwin meeting happened (5/25 18:34 UTC log). Tom 1:1 outcome not logged but holiday is past. Retiring.
- **Stuart Styron Wed 5/27 Atlanta dinner** — past. No outcome logged in any 5/27-5/30 daily. Retiring the "time-sensitive Wed 5/27" framing; the Atlanta visit / team call follow-up / LinkedIn / intros pieces become low-grade carry-forward (see §1 hot replies).
- **Steven Bridges LinkedIn invite (5/05)** — overtaken by his 5/29-30 substantive concept-note reply. Retiring the invite-pending watch; the reply itself is now in §1.
- **Bridges-flagged "scaling >200 in pilot" question** — captured this week, now part of the hot-reply queue, not a separate item.

Carry-forward items at risk of formal retirement next cycle if no outcome captured:

- VDACS AFID / USDA VAPG / VAFAIRS / VT Climate-Smart / Southern SARE — passed Apr/May without outcome. **Third cycle on watch list. Propose formal "outcome unknown, dropped" entries next week unless Kennon supplies status.**
- **Marc-proposed Chasen ↔ Steve / Vince Dean / Jeff Melnick** March intros — third cycle without resolution. **Likely best treated as superseded by TS v2 motion.** Same posture next week.
- **VTC America 250** — closed 5/28 with no go/no-go logged. Mark as "passed without action" next cycle.
- **Stuart Styron** — if no outcome surfaces by next cycle, retire as "Atlanta visit and follow-ups never resurfaced; relationship dormant."

---

## Index of source files reviewed

- `MEMORY.md`, `RECOVERY.md`, `RADAR.md`, `HEARTBEAT.md`
- `memory/topics/certify-ai.md` (2026-05-27, current — reflects v2 + business case)
- `memory/topics/khan-university.md` (2026-05-19, JA Worldwide section current)
- Daily logs 2026-05-22 through 2026-05-30 (9 logs; verified continuous coverage)
- `ets-skills/certify-ai/` directory (term sheets v1 + v2 + onepager, WIOA v2, lighthouse matrix, brief artifacts, Series A template)
- `ets-skills/linux-foundation/` directory (three press release lineage — unchanged)
- `ets-skills/exports/` directory (Certify.ai negotiation brief + Chasen one-pager 5/27 new)
- `research/certify-ai-business-case/` directory (BC, assumptions, 36-mo CSV, reconciliation)
- `backups/` directory state (5 snapshots: 5/4, 5/10, 5/17, 5/24, 5/31)
- `research/expenses/` CSV directory state (5/23-5/30 continuous; 5/20, 5/22 still missing) and `budget-tracking-2026-05.md` (last updated 5/10)
- `backups/athena-state-2026-05-31/README.md` (this cycle's backup summary; corroborates state changes)
