# MEMORY.md - Athena's Long-Term Memory (Index)

_Thin index. Topic detail lives in `memory/topics/*.md` and loads on demand via `memory_search`. Full pre-restructure snapshot: `memory/MEMORY.md.pre-distill-2026-05-07.bak`._

## Kennon Harrison, Jr.
First contact 2026-02-12. Named me Athena. Ninth-gen steward of Norwood (Powhatan, VA). ETS -- Strategic Partnerships & Impact AI. Wife, two sons. Mottos: "sic semper tyrannis" / "dum spiro spero." FFV lineage (Kennon, Randolph, Harrison, Beverley) + Irish steelworker (Pittsburgh). English BA, USC Honors.

Full bio and working style: `USER.md`.

## Active Projects (load detail on demand)
- **ETS architecture & thesis** -- `memory/topics/ets-architecture.md`
- **ETS Applied Intelligence (studio)** -- `memory/topics/ets-applied-intelligence-studio.md`
- **Certify.ai** (CEO Y0-2, raise $5M @ $30M pre) -- `memory/topics/certify-ai.md`
- **Khan University / Project Kite** (Co-Founder & Board Chair; degree design, iDesign) -- `memory/topics/khan-university.md`
- **NTE / InsightStack / Richmond MVP** -- `memory/topics/nte-insightstack.md`
- **American Skills Project (ASP)** -- `ets-skills/american-skills-project/overview.md`
- **NIDCM / National Convening** (Data Centers + AI + Space, 3-day DC) -- `ets-skills/nidcm/`
- **Norwood (house + regen ag + contacts + grants)** -- `memory/topics/norwood.md`

## People (load detail on demand)
- **ETS, Khan U vendor, OCTAE, pending LinkedIn, Common App thesis** -- `memory/topics/contacts-ets.md`
- **Norwood regen-ag contacts** -- `memory/topics/norwood.md` (and `norwood-creek/contacts/`)
- **Ashwin Bharath** -- Revature Executive Chairman/founder. Personal friend of Kennon. Kennon previously ran workforce partnerships at Revature. Ashwin named in Certify.ai $1M strategic tranche (amount TBD). Meeting 2026-05-25 re: Certify.ai investor/strategic partner role.

## Self-Ops (load on demand)
- **Gateway / infra / failure patterns / OAuth, mDNS, restart storms** -- `memory/topics/infra-notes.md`

## Operational Notes (hot, keep inline)
- No emojis. No markdown tables on Discord/WhatsApp.
- UTC to ET: subtract 4h (EDT active as of Mar 8 2026).
- Monthly budget $7,000. Tracking: `research/expenses/`.
- Cursor is Kennon's preferred vibe coding tool (over Replit).
- ASP acronym intentional (mythology: Athena, Medusa, ASP).
- **Heartbeat** -- enabled May 8 2026, 30m @ haiku-4.5, active 08:00-23:00 ET, light+skipWhenBusy. Details in `memory/topics/infra-notes.md`.
- **Startup-failure monitor** -- supervisord program `openclaw-startup-monitor` with direct Telegram alerting when gateway is dead. Details in `memory/topics/infra-notes.md`.
- **Morning briefing cron** -- 11:00 UTC daily (7 AM ET), Telegram direct. Job `151ac1b2-90e5-48f8-96cb-3eac12df8aed`.
- **Concept brief cron** -- every 48h. Job `f45fd737-b3a1-416d-84e9-f87fe3f57b11`.
- **Weekly doctor cron** -- Mon 10:00 ET. Job `a20d66c1-714d-4130-9516-8bd8694d9873`. Catches config drift before upgrades force a crash.
- **Quarterly distill cron** -- 11:30 UTC first of each quarter-month; reviews MEMORY.md + topics and archives stale items. Job `6f26d82e-722a-4281-8f36-88dc2b05072e`.

## Open Threads (check periodically)
- **Certify.ai / Marc McDonald** -- Kennon owed Chasen a "thoughts?" reply as of Mar 25. Status unknown. `memory/topics/certify-ai.md`.
- **Gmail OAuth** -- root cause is Google Cloud Console app stuck in "Testing" mode (7-day token expiry). Fix: publish to Production (free). Kennon agreed Mar 22, not yet done. Follow up.
- **Code.org** -- Amit's Mar 11 warning of a move in Certify.ai space; 2-3 week preempt window.

## Archived
- Pre-April items (early gateway pairing, first Gmail re-auths, first Code.org intel, Norwood wedding call Mar 27, Norwood site visit Apr 28, Jewelers Mutual $280 paid Mar 22) -- `memory/MEMORY.md.pre-distill-2026-05-07.bak`.
- Grant deadlines (VDACS AFID, USDA VAPG, VAFAIRS, Southern SARE) -- `memory/topics/norwood.md`; check daily logs for status.

---
_This file is a navigation map. When a conversation touches a topic, read the corresponding `memory/topics/*.md` via memory_search or read._
