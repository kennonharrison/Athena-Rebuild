# Gateway / Infra Notes (Athena self-ops)

## Environment
- Docker container, bridge network 172.17.0.3
- Supervisord starts the gateway; `/tmp/supervisord-openclaw.conf` controls env vars
- Config path: `~/.openclaw/openclaw.json`
- Runtime status: `openclaw status` (add `--deep` for probes)
- Logs: `/tmp/openclaw/openclaw-YYYY-MM-DD.log`

## Failure patterns

### Restart storms are the biggest failure mode
Three gateway restarts in four minutes = guaranteed event-loop stall (10-20s delays) → "incomplete terminal response" + `payloads=0` → perceived failure loop. Each restart stages `chokidar` via pnpm install (1.4-9.7s blocked).

**Don't stack restarts.** Prefer `config.patch` (hot-reloads) over `restart`. Let one restart fully settle before even considering another.

### Bonjour/mDNS probe churn
In this container there are no mDNS consumers, so Bonjour loops `probing → advertised → restarting` every 10 seconds indefinitely. Cosmetic log noise, small steady CPU.

Disable paths:
- `discovery.mdns.mode: "off"` in `~/.openclaw/openclaw.json`, OR
- `OPENCLAW_DISABLE_BONJOUR=1` in supervisord env

**Both are protected config paths** -- cannot hot-patch via `gateway.config.patch`. Requires direct file edit + gateway restart. Not urgent; leave it unless doing other restart work.

## MEMORY.md bootstrap
- Default `agents.defaults.bootstrapMaxChars` = 12000 (protected path)
- Silent tail truncation when MEMORY.md exceeds cap
- Structural fix: keep MEMORY.md as a thin index (≤4K chars), move topic-heavy content to `memory/topics/*.md` and load on demand via `memory_search`
- Distill whenever MEMORY.md creeps past ~10K

## Failure diagnosis rule
"Incomplete terminal response" + `event_loop_delay` warnings = **host/gateway problem**, NOT a model problem. Do not swap the fallback chain or the model. Investigate gateway load (restart storms, Bonjour churn, mDNS, memory pressure).

## Key operational settings
- **Heartbeat:** enabled May 8 2026. `agents.defaults.heartbeat.every = "30m"`, model `myclaw/claude-haiku-4.5`veHours 08:00-23:00 America/New_York`, `lightContext + skipWhenBusy` on. Protected path: edit the JSON directly and hot-reload via file watcher (touch the config), do NOT use `gateway.config.patch` (it rejects all heartbeat keys).
- **Monthly budget:** $7,000. Tracking in `research/expenses/`
- **Morning briefing cron:** 11:00 UTC daily (7 AM ET), Telegram direct. Job ID: `151ac1b2-90e5-48f8-96cb-3eac12df8aed`
- **Concept brief cron:** every 48h. Job ID: `f45fd737-b3a1-416d-84e9-f87fe3f57b11`
- **Weekly doctor cron:** Mon 10:00 ET. Job ID: `a20d66c1-714d-4130-9516-8bd8694d9873`. Surfaces config drift before the next upgrade forces a crash loop.

## Startup-failure monitor (independent of gateway)
Added May 8 2026 after 21h outage on May 7-8.
- Script: `/home/ubuntu/.openclaw/startup-failure-monitor.sh`
- Supervisord program: `openclaw-startup-monitor` (runs as `ubuntu` user)
- Watches `/home/ubuntu/.openclaw/logs/stability/` for `gateway.startup_failed` bundles
- Thresholds: 3 failures in 300s triggers alert; 1h cooldown between alerts
- Delivery: direct Telegram Bot API call (reads token + chat id from `openclaw.json`). Works when the gateway is dead.
- Log: `/home/ubuntu/.openclaw/startup-failure-monitor.log`

### The May 7-8 outage (kept for reference)
Outage 2026-05-07 02:58 UTC → 2026-05-08 00:25 UTC (≈21.5h). Root cause: OpenClaw upgraded to 2026.5.6 on May 7, config had `channels.telegram.dmPolicy` at a path the new stricter schema rejected as `additionalProperties`. Supervisord (`startretries=2147483647`, not the watchdog — watchdog hasn't run since March 26) crash-looped every ~60s. Fixed by running `openclaw doctor --fix` which rewrote the config at 00:24:35 UTC. No external alerting had visibility; Telegram bot was down the whole time. Monitor + weekly doctor cron are the fix.

## Pending ops fixes
- **Gmail OAuth:** broken 5+ times (Feb 23, Mar 3, Mar 13, Mar 20, others). Root cause: Google Cloud Console app in "Testing" mode = 7-day refresh token expiry. Fix: publish to "Production" (free, no downside). Kennon agreed Mar 22, **NOT done**. Follow up.
