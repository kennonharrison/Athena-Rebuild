# Certify.ai

## Positioning
AI literacy certification AND portfolio connective layer. Gateway to ASP/WPR (skills profiles seed talent matching) and credentialing layer for Project Kite/Khan U (embedded in degree programs, PLA credit path).

## Leadership
- Kennon = CEO (through ETS Applied Intelligence studio)
- Michael Chasen = Co-Founder & Vice Chairman (capital raises, IR)

## Raise (current — Term Sheet v2, 2026-05-26)
**$8M at $40M pre-money / $48M post-money.** Priced Series Seed (NVCA-modeled). Delaware **PBC**. Target close: end of July 2026.

### Round composition
- ETS $2M — **Co-Lead**
- Linux Foundation $2M — **Co-Lead** (retained co-lead status; signaling value justified)
- Chasen Strategic Syndicate $2M — names TBD before close (Kennon confirmed real, undetermined)
- Strategic Anchor Tranche $2M — ~$500K per participant: iDesign, Nick Davis (MOFC = Mid-Ohio Food Collective, Feeding America affiliate), Mike Torrence (Motlow CC, personal), Ashwin Bharath. Final allocations TBD before close.

### Cap table (fully-diluted, post-money)
- Kennon + Chasen combined: **58.33%** (35% pre × 40/48; default 50/50 split between them, confirm)
- ETS total: **16.67%** (12.50% sponsor stake + 4.17% cash)
- Linux Foundation: **4.17%**
- Chasen Syndicate: **4.17%**
- Anchor Tranche: **4.17%**
- Option Pool: **12.50%** (15% pre × 40/48)

### Key structural terms
- **ETS sponsor stake:** 15% pre-money FD, granted at incorporation, no IP transfer, consideration = studio origination + SCA framework.
- **Co-Lead Consent Right:** ETS and LF each have separate consent on (i) amending PBC purpose, (ii) Company Sale within 3 years of close, (iii) down-round, (iv) terminating their respective SCA. Sunsets at <3% post-money FD.
- **Board:** 5 seats — Kennon, Chasen, ETS director, LF director, mutually-agreed independent. Co-Lead director seats sunset to observers on <10% post-money FD ownership, missed 18-month commercial milestones, or 12-month commercial inactivity. Founders retain control via the independent swing seat (Founder-and-Co-Lead-approved).
- **Two SCAs:** ETS SCA (Aladdin MSA, Praxis 50/50 rev share, distribution ROFR ETS-channels-only) + LF SCA (co-marketing, Agentic AI Certifications ecosystem positioning, curriculum 30% rev share base / 20-40% range). Both are separate closing conditions interlocked with equity.
- **Founder vesting:** 3yr monthly, 1yr cliff, double-trigger acceleration on Company Sale. (Employees remain 4yr / 1yr cliff.)
- **Legal fee cap:** $50K aggregate, split between Co-Leads.
- **No-shop:** 45 days.
- **Use of proceeds:** ~24 months runway. ~$3.6M headcount, ~$600K Odyssey X, ~$700K content, ~$600K sales/BD, ~$400K legal, ~$600K G&A, ~$400K marketing, ~$1M reserve.

### Term Sheet Decisions (Kennon answers — 2026-05-14 + 2026-05-26 reconciliation)
- **Entity:** Delaware **PBC** (locked 2026-05-20).
- **IP/Assets:** Cash only — no IP contribution from ETS, no reversion rights.
- **Kennon role:** Leaving ETS to run Certify.ai full-time.
- **Process:** Outside counsel to be engaged before circulation. Priced Series Seed (not SAFE).

## Documents (current)
- Term sheet v2 (current): `ets-skills/certify-ai/certify-ai-series-seed-term-sheet-v2.md`
- Term sheet v1 (superseded): `ets-skills/certify-ai/certify-ai-series-seed-term-sheet-v1.md`
- Business case (overnight 5/25-26): `research/certify-ai-business-case/certify-ai-business-case.md`
- Model assumptions: `research/certify-ai-business-case/certify-ai-model-assumptions.md`
- Financial model (36-mo CSV): `research/certify-ai-business-case/certify-ai-financial-model.csv`
- Reconciliation analysis: `research/certify-ai-business-case/RECONCILIATION-termsheet-vs-businesscase.md`

## Open items before external circulation
1. Lock Chasen Syndicate $3M names + individual allocations.
2. Lock Strategic Anchor $1M composition (which candidates actually in, sizes).
3. LF curriculum-tier rev share final % (range 20-40%, base 30%).
4. Confirm founder split between Kennon and Chasen of the combined 58.33% (default 50/50).
5. Engage outside counsel before any external circulation.
6. Reconcile Channel 1 volume between assumptions doc (~5,500 Y1 exams) and financial model (~1,750 Y1 exams) — material gap flagged in BC Open Question #3.

## Financial trajectory (per business case)
- Y1: $1.37M rev / $2.76M cost / -$1.39M NI. Cash-flow positive Month 11. Cash trough Month 10 at $6.23M.
- Y2: $9.41M rev / $4.06M cost / +$5.36M NI.
- Y3: $37.50M rev / $5.75M cost / +$31.75M NI.
- 36-mo cumulative: $48.3M revenue. EoY3 cash: $47.7M.

## Cold start solved
Enterprise, institutional, and government buyers need it independently of any single use case.

## Key docs
- `ets-skills/certify-ai/portfolio-architecture.md`
- `ets-skills/certify-ai/portfolio-exec-summary.md` (exec summary for Amit)
- `ets-skills/certify-ai/tam-proof-points.md`
- Pitch deck: `certify-ai-pitch-deck-vfinal.pdf` (37 slides, workspace root)

## Marc McDonald / ETS Response (Mar 23, 2026)
Marc = Chief of Staff to CEO Amit. `mmcdonald@ets.org`, +1-202-457-8689.

ETS team in discussions: Amit, Emal, Steve, Janet, Shruti, Marc.

### Positive signal
"Completely agree" on AI cert signals. ETS wants "high impact, high scale role."

### Five concerns
1. ETS resource dependency / investment structure
2. GTM without mandates
3. No MVP
4. Differentiation vs Code.org / Khan / Coursera
5. Pricing / shelf-life assumptions

### Three proposed next steps
1. Chasen ↔ Steve (ETS AI capabilities, DC Wed Mar 26)
2. Chasen ↔ Vince Dean (Praxis lead, distribution + AI assessment)
3. Meet CFO Jeff Melnick (deal structure)

### Open thread
Kennon had not yet responded to Chasen's "thoughts?" as of Mar 25. **Check status.**

Detailed analysis in `memory/2026-03-25.md`.

## Competitive / regulatory tailwinds
- **Code.org** is NOT a competitor -- it's a feeder (free curriculum, no cert/assessment). Potential partnership target. Hadi Partovi outreach flagged. Amit warned Mar 11 that Code.org is planning a move in Certify.ai's space; 2-3 week preempt window.
- **DOL AI Literacy Framework** (Feb 13 2026, TEN 07-25): 5 content areas + 7 delivery principles. Certify.ai Impact Framework aligns nearly 1:1. Federal workforce funding flowing toward alignment.
- **EU AI Act Article 4** (effective Feb 2 2025): legal mandate for AI literacy of all staff at EU-deploying organizations. Civil liability from Aug 2 2025. Major TAM driver for enterprise / international play.
