# Aladdin Pedagogical Progression -- Competitive Scan (May 17, 2026)

## The framework being scanned
Three-phase progression on a continuous Bayesian measurement substrate (Aladdin):
1. AI tutor + performance-based task (solo, clean signal)
2. Agentic peers + performance-based task (simulated social, prescribable challenge)
3. Real peers + performance-based task (authentic social, noisy signal)

## Closest direct analog
**APCP framework** (arXiv 2508.14825, "From Passive Tool to Socio-cognitive Teammate") -- four levels of AI agency:
- Adaptive Instrument
- Proactive Assistant
- Co-Learner
- Peer Collaborator

Maps closely to Kennon's Phase 1 -> Phase 2 arc. But APCP is a *conceptual framework about AI's role*, not a measurement-anchored learning progression with a continuous Bayesian posterior carrying through all phases. It describes agency levels, not a designed pedagogical sequence ending in real-human peer work. **No measurement layer.**

## Adjacent work (each gets part of it, none get the whole)

**Intelligent tutoring + Bayesian knowledge tracing**
- Decades of work (Corbett & Anderson BKT, PFA, DKT, recent neural extensions). Masaryk overview confirms BKT/logistic models as standard.
- Strong on Phase 1 measurement. No agentic-peer phase. No real-peer entanglement modeling. ETS Aladdin's edge: continuous posterior persisting across modalities, not just within one item sequence.

**Agentic AI in education (state-of-the-art surveys)**
- Springer 2024 chapter, IEEE survey, MDPI 2025, ScienceDirect AIA-PAL, Tandfonline AIA-PCEK.
- All frame agentic AI as tutor/companion/mentor. None frame agentic AI as a *deliberately prescribed peer-dynamic stressor* designed to bridge solo learning to human peer work.
- None pair agentic peers with a continuous psychometric posterior.

**Multi-agent learning environments**
- ScienceDirect "Mapping student-AI interaction dynamics in multi-agent learning" (2025) -- simulates teacher + peer roles, studies interaction patterns. Closest empirical work to Phase 2.
- Google Research "science of scaling agent systems" -- finds more agents isn't always better; task alignment matters. Relevant constraint for Phase 2 design.
- No measurement-anchored progression to Phase 3 with real peers.

**Peer assessment scaffolding (traditional)**
- ScienceDirect 2018 -- scaffolding peer-assessment skills works only when domain skills are sufficient. Empirical support for the *order* in Kennon's progression (solo competence before peer work).
- Pure human pedagogy literature. No AI peers, no Bayesian backbone.

**Simulation-based assessment (enterprise)**
- Mursion (VR avatars, human-puppeteered), STRIVR, Bodyswaps. Stage social scenarios for training and assessment. Closest commercial analog to Phase 2.
- Limitations: avatars are puppeteered or scripted, not truly agentic. Measurement is rubric-based, not continuous Bayesian. No bridge to real-peer Phase 3 with persistent posterior.

**Khan Academy / Khanmigo, Pearson, Coursera AI tutors**
- All anchored in Phase 1. Khanmigo has experimented with role-play (debate partners, historical figures) -- early Phase 2 gestures, no measurement spine.
- None have published a Phase 3 (real peer) measurement integration tied to the same learner posterior.

**ETS internal**
- PRAXIS, GRE, TOEFL, HiSET -- traditional psychometrics. Aladdin appears to be the first ETS effort genuinely positioned for this kind of progression.

## The differentiation claim
Nobody combines all four of:
1. Continuous Bayesian measurement posterior persisting across modalities
2. Deliberately designed three-phase social-complexity progression
3. Agentic peers prescribed as social-stressor instrument (not just tutor-with-personality)
4. Multi-party Bayesian disentanglement for real-peer Phase 3

The framework + Aladdin is genuinely novel as a *system*. Individual components exist; the integration doesn't.

## Commercial implications for Certify.ai and KTI

**Certify.ai positioning:**
- Today's value prop: AI literacy + first-vertical assessment
- With this framework: a *complete pedagogical model* that other certifying bodies (CompTIA, AWS, Microsoft, industry-specific certs) can license. ETS sells the system, not the assessment.
- Particularly strong for certifications where human interaction is part of the competency (sales, customer service, healthcare, leadership, teaching). These are exactly the certs that have struggled to measure beyond multiple-choice.

**KTI / Khan University:**
- Differentiated degree design: Phase 1 -> 2 -> 3 progression baked into curriculum. Every course produces signal that feeds the unified posterior.
- Becomes a recruiting story to faculty and partners: "we're the only university designed around continuous measurement of skill transfer."
- Defensible against any university that bolts on AI tutoring later -- they'd be stuck at Phase 1.

**ETS as licensor:**
- The combined "pedagogy + measurement capability" is the product.
- Sells to: other universities (KTI as reference), professional cert bodies, corporate L&D, K-12 systems, workforce programs.
- Higher margin than test-delivery. Trust + IP + measurement science, not commodity proctoring.
- Reinforces the broader thesis: ETS = trust infrastructure for human capital. The framework is the operationalization.

## Risks and open questions
- Phase 2 fragility: agentic peers must be genuinely peer-like (struggling, inconsistent, distractible, sometimes wrong), not optimized assistants in disguise. Requires deliberate design constraints.
- Phase 3 disentanglement: requires scale of pairings. Smaller cohorts (early KTI) may struggle to produce clean signal.
- Skills without natural Phase 3: parallel track or honest acknowledgment that some competencies max out at Phase 2.
- IP and publication strategy: is this a paper, a patent, both, neither? Probably both -- paper to establish authority, patent on the multi-party Bayesian disentanglement method.
- Phase 0 (diagnostic intake) and Phase 4 (learner-as-agentic-peer-source) deserve their own design passes.

## Recommended next moves
1. Decide whether to brief Aladdin team specifically on this progression (vs. letting them discover the framing organically)
2. Identify one Certify.ai cert family to pilot the full progression on -- ideally one with strong human-interaction component
3. White paper draft: "Continuous Measurement Across the Solo-Simulated-Social Learning Arc" -- ETS as author
4. Map which existing ETS skills/cert IP feeds each phase cleanly
5. Patent counsel review of multi-party Bayesian disentanglement approach
