# ETS Applied Intelligence (Studio)

Confirmed March 2026.

## Mission statement
"ETS Applied Intelligence leverages the trust ETS has built over 75+ years of service to the world's talent development ecosystems to drive value for people, governments, and employers at global scale."

## Structure
- **Kennon** = Managing Director
  - CEO of Certify.ai (Year 0-2)
  - Co-Founder & Board Chair of Khan U
  - Architect of ASP
- **Michael Chasen** = Co-Founder & Vice Chairman of Certify.ai
  - Capital raises + IR
  - Does NOT want to run Certify.ai day-to-day
  - Wants Kennon as operator, himself as fundraiser. Agreed split.

## Brand architecture
ETS (Layer 1 trust) > ETS Applied Intelligence (Layer 2 studio) > Certify.ai, Khan U/UAI, ASP/ProFound (portfolio).

Tagline: "Trust is the platform. Intelligence is what you build on it."

## Financial target
$1M non-property assets → $10M in 15 years.

## Minimum terms
- 20% carry (≥50% GP share)
- 30%+ personal studio equity
- 2% management fee
- Co-investment at par
- 15-year or evergreen fund

## Sequencing
- Launch ventures: Certify.ai + ASP
- Norwood Phase 2 included from day one (avoid mission-creep optics)
- Khan U as structured partnership

## Key docs
- `ets-skills/applied-intelligence-studio.md` (studio overview)
- `ets-skills/two-layer-thesis.md` (layer 1/layer 2 architecture)

## Status
Kennon met with Amit March 11 afternoon (with Chasen) to discuss Certify.ai + studio structure. Outcome pending as of last check.
