# Certify.ai CC GTM -- Full Pre-Crash Context (from Gmail draft "Athena Context")

_Recovered 2026-05-08 from Kennon's Gmail draft containing the full pre-crash Telegram conversation._

## Origin

Kennon met Drew Bercich at NAWB. Drew confirmed WIOA eligibility for the Certify.ai + KTI + ETPL stack is legitimate and offered to help.

## Product Architecture (locked)

Three commercial objects:

1. **Certification-only** -- distinct SKU, $100, low-friction top-of-funnel
2. **General Certify.ai pathway** -- full pathway, $2,500-$3,000 price band, Certify.ai revenue $500/learner
3. **KTI-inclusive pathway** -- premium, $4,750 anchor, Certify.ai revenue $500/learner

Product structure assumes Linux Foundation investment/endorsement and ETS investment/endorsement.

Original product components: (1) Learning content (Linux co-developed), (2) Lab content (Linux co-developed + ETS Aladdin-delivered), (3) Certification (Linux/AI-edu co-developed, ETS validated/approved/endorsed).

## Stackable Pathway Model (locked)

- General Certify.ai credential = credit-bearing on-ramp into KTI
- Certify.ai receives $500 affiliate bounty per KTI conversion
- General pathway is ALSO: flagship Aladdin entry product, feeder into Linux Foundation advanced AI certs (esp. agentic AI), feeder into employer/staffing/workforce systems
- Multi-destination ecosystem funnel, not a single ladder
- Weak "add-on model" (bolt cert onto existing degree) explicitly rejected -- do not use

## Workforce Pell Logic

- No: attaching Certify.ai to any associate's degree does NOT make it Workforce Pell eligible
- Yes: Certify.ai can strengthen a properly designed short-term, stackable, credit-bearing workforce pathway that articulates into an associate's degree and could qualify for Workforce Pell
- Structure A and B (embedded vs standalone-then-articulate) are effectively the same offering with different sequencing -- treat as one core stackable pathway design with flexible entry motions

## Channel Structure (locked)

Primary named channels:
1. WIOA / ETPL
2. Praxis / educator distribution (PRIMARY non-WIOA channel)
3. ETS-mediated employer / institutional distribution
4. Other non-WIOA partner channels (staffing, workforce nonprofits, public-sector, higher-ed direct)

Product-leading logic by channel:
- General Certify.ai leads in: WIOA, Praxis, broad-access pathways
- KTI-inclusive leads in: employer, selected CCs, some workforce-development buyers
- KTI should NOT lead with 4-year colleges (they are competitors) -- HARD CONSTRAINT

## Financial Assumptions (locked)

### Revenue
- Certify.ai direct: $500/learner in both pathway products
- Cert-only: $100/learner
- KTI affiliate bounty: $500 per converted learner
- KTI conversion rates (conservative): cert-only -> KTI 2%, general pathway -> KTI 8%

### Costs
- ETS/Aladdin implementation capex: $300,000 one-time
- ETS per-learner service: $30 (full-program), $10 (cert-only)
- Support/partner/overhead: $20/user average
- No marketing cost
- Annual staff: $1,000,000
- Capex per non-KTI full pathway build: $200,000 each
- Year-one builds: teacher full-path + general full-path = $400k capex

### Praxis specifics
- Cert-only at $100
- Full pathway (lighter educator-specific version) at $500
- WIOA funding of AI certs for teachers: possible (Alex Kotran at AIEDU thinks it's being done), but not assumed in base case

### CC specifics
- $50/contact hour minimum gross revenue (what CC leaders expect)
- 5 cohorts/year x 20 students/cohort = 100 learners/year per CC partner
- Each CC partner worth ~$49k annual contribution to Certify.ai
- Each CC partner generates $250k-$300k gross annual program revenue at current pricing

### Break-even
- CC-only: ~21 partners steady-state, ~35 year-one
- Mixed-channel: ~14 CC partners closes year-one gap
- Target: **15 active full-pathway CC partners**

## CC Targeting Methodology

### Scoring model
- Channel Readiness: 35%
- Market Opportunity: 40%
- Institutional Urgency: 25%

### ETPL = HARD GATE (May 6 correction)
- If not on state ETPL as approved provider, institution does NOT make the list
- This is a threshold filter, not a weighted scoring factor
- Correct question: "Which ETPL-approved community colleges are the strongest targets?"

### Correct workflow
1. Finish 50-state ETPL source list
2. Verify ETPL presence for candidates
3. Remove non-ETPL schools
4. Score only ETPL-approved remainder
5. Backfill with additional ETPL-approved schools

### Relationship targets (10 institutions)
- Motlow State CC
- Brightpoint CC (+ CCWA)
- South Central CC
- Dallas College
- Northern Virginia CC (NOVA)
- Wake Technical CC
- Borough of Manhattan CC (BMCC)
- KCKCC
- Central Ohio Technical College

### Empirical top 20 (pre-ETPL-gate, strategic hypothesis only)
1. Dallas College
2. NOVA
3. Wake Tech
4. Miami Dade
5. Houston CC
6. Austin CC
7. Central Piedmont CC
8. BMCC
9. Cuyahoga CC
10. Broward College
11. Brightpoint / CCWA
12. Lone Star College
13. Montgomery College
14. CC of Baltimore County
15. Columbus State CC
16. Pima CC
17. Tidewater CC
18. Prince George's CC
19. Sinclair CC
20. Salt Lake CC

### IPEDS data
Kennon provided IPEDS ZIP with multi-year revenue, headcount, non-degree vs degree-seeking splits, expense data. Not yet processed because ETPL gate must come first.

## ETS Revenue Model

- NOT direct ETS revenue -- this is Certify.ai revenue via ETS services provided to Certify.ai
- ETS role: enables distribution, validation, infrastructure, service delivery that supports Certify.ai economics
- Do not frame as separate ETS margin line

## Linux Foundation Assumptions

- Strategic endorsement/halo (critical to WIOA eligibility)
- Downstream progression revenue (conservative)
- Unlikely to spend on top-of-funnel
- Conversion rate on them and their admissions process
- Certify.ai won't spend much to guide students to LF -- discount accordingly

## Optimization Objective

Optimize first for FASTEST ADOPTION, not maximum margin or maximum stack revenue.

## Key People Mentioned
- Drew Bercich (NAWB) -- confirmed WIOA eligibility, interested in helping
- Alex Kotran (AIEDU) -- believes WIOA funding of AI certs for teachers is already happening
- Vince Dean (ETS/Praxis connection, from earlier memory)

---
_Source: Gmail draft "Athena Context" (message ID 19e0541661ccd8ff), recovered 2026-05-08._
