# ETS Architecture & Thesis

## Core organizing principle (Apr 25, 2026)
AI is the horizontal wedge that lets ETS collect durable skills data across every vertical and build a cross-industry readiness data structure. Most see AI as a vertical application; Kennon sees AI as the cross-industry data-collection mechanism. Verticals aren't the moat -- the horizontal readiness data structure is.

## Flywheel
1. AI creates urgency and adoption pressure across every vertical
2. Urgency creates permission to deploy measurement (Certify.ai, Readiness Lab, KTI)
3. Measurement in each vertical generates durable skills data
4. Durable skills data from many verticals creates cross-industry readiness structure
5. Readiness structure makes every subsequent vertical measurement more powerful
6. Readiness structure becomes routing + opportunity-matching infrastructure

## Moat durability
Replication requires: many verticals participating, longitudinal data, real-world outcomes feedback, trust infrastructure, measurement science rigor. Any single vertical can be copied; the cross-industry structure cannot.

## One-sentence thesis
AI is not the product category. AI is the wedge that creates the cross-industry readiness data infrastructure, which is the actual product category.

## Order of operations
- **Certify.ai** -- seeds AI literacy + first vertical data flows
- **KTI / Khan U** -- seeds higher ed, adds outcomes tracking + deeper skills signal
- **Workforce partners** -- add placement + employment outcomes
- **Readiness Lab** -- persistent measurement environment

All feeds one structure.

## Long-term Common App ambition (Apr 25, 2026)
Eventually replace traditional college admissions by acquiring Common App and inserting readiness measurement at point of application. Common App processes ~1M applicants/year to ~1,000 colleges. Current gatekeeping (grades, essays, transcripts) is loosely predictive and gameable. If ETS inserts readiness-linked signal at application, it becomes the trusted measurement authority for the entire admissions system. Connects to skills genome, NTE architecture, readiness systems theory, broader talent-to-opportunity matching.

## ETS strategic vision
ETS = trust infrastructure for human capital, not a testing company.

Two imperatives:
1. Advance measurement science: near-zero cost, near-perfect signal, near-perfect access, anonymity + transparency
2. Be the foundational trust/measurement layer for all human-computer interaction globally

## Kennon's ETS role
Manages all strategic AI partnerships globally for ETS. Every AI lab, platform, enterprise AI conversation is within his mandate -- not external outreach, core job. Also built Futurenav (Edge + Compass) -- the durable skills assessment that is the core measurement layer for the entire NTE/InsightStack architecture.

## Project Aladdin → Odyssey X (May 17, 2026; naming resolved Jun 7)
ETS's internal continuous measurement capability. **Bayesian inference-based** -- not a snapshot summative engine. Every learner interaction is treated as evidence; the posterior estimate of skill/knowledge state updates continuously.

Why this matters architecturally:
- Enables the "near-zero cost, near-perfect signal" imperative -- you don't need a high-stakes event to update belief
- Pairs naturally with the skills genome / readiness data structure -- probabilistic substrate keeps the graph honest as evidence accumulates
- Foundation for embedded direct assessment (referenced Apr 25 -- "most direct assessment will be via Aladdin embedded inside Readiness Lab")
- Aligns with where psychometrics needs to go: away from snapshot reliability toward continuous, evolving certainty

Name lineage: ETS Aladdin predates / parallels BlackRock's Aladdin (also a Bayesian-flavored risk measurement system). Distinct project.

**NAMING UPDATE (2026-06-07):** Aladdin was v0.1. Odyssey X is v1. Aladdin no longer exists as a standalone name — Odyssey X contains Bayesian continuous measurement by default. All new documents should use "Odyssey X" only. Legacy docs (term sheets, SCAs, white paper outlines) retain "Aladdin" for historical accuracy but should be updated before external circulation.

## Pedagogical Progression Framework (May 17, 2026 -- draft)
Kennon's three-phase learning/assessment arc built on Aladdin's continuous measurement substrate. Posterior on the learner persists across all phases -- not three separate assessments, one evolving estimate.

**Phase 1:** Formative learning w/ performance-based tasks + AI tutor support/instruction (solo, clean signal)
**Phase 2:** Formative learning w/ performance-based tasks + agentic "peers" (simulated social, prescribable social challenge)
**Phase 3:** Performance-based tasks/projects/interactions with actual peers (real social, authentic but noisy signal)

Two simultaneous gradients: social complexity (solo -> simulated -> real) and measurement fidelity (clean -> mixed -> noisy-but-authentic).

**Phase 2 is the differentiated capability.** Agentic peers let ETS stage social dynamics that can't be reliably produced in Phase 3 -- adversarial collaborators, struggling partners, dominant personalities, cultural mismatches. Prescribable social challenge. Fragility: if agentic peers are too competent/consistent, it's just tutor-with-a-costume.

**Phase 3 measurement challenge:** learner's performance entangled with peer's performance. Multi-party Bayesian inference can disentangle only with sufficient interactions across enough peer combinations. Scale becomes a measurement feature, not just a business feature.

**Open questions:**
- Phase 0: Aladdin diagnostic profiling to personalize Phase 1 entry point?
- Phase 4: do learners become agentic peers for next cohort? (closes loop, makes teaching itself measurable evidence)
- Skills without a natural Phase 3 analog (deep technical work) may need a parallel track

**Commercial thesis:** combined pedagogical model + measurement capability -- a differentiated foundation for Certify.ai and KTI that ETS can license/sell to other cert and education clients. Sells the *system* (pedagogy + Aladdin), not just the assessment. See `memory/topics/aladdin-pedagogy-competitive-scan.md` for the May 17 landscape scan.
