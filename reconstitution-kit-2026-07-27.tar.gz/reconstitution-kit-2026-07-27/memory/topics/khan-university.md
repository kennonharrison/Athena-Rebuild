# Khan University (Project Kite)

## Deal
- $3,500 applied AI degree
- JV with Khan Academy
- Internal codename: Project Kite
- Certify.ai = credentialing layer (embedded in programs, PLA credit for cert holders)
- Details: `ets-skills/khan-university/`

## Naming
- Structure: "University of ___". Name stands alone on resume; "powered by ETS, Khan Academy, and TED" underneath.
- **Leading candidate: "University of Applied Intelligence" (UAI)**
  - Passes resume test
  - "Applied" signals practical
  - "Intelligence" expansive beyond AI
  - Clean abbreviation
  - Minor defense/intel overlap assessed as feature in DC circles
- "Applied Intelligence" is also the studio name -- intentional brand coherence
- No final decision yet

## Allan Fisher -- Degree Design
Consultant brought in by Amit Sevak.

Background: former Sr Director of Academics at Emeritus, former Associate Dean at CMU SCS, co-author of "Unlocking the Clubhouse."

### Concern raised
Questioned marketability of BS in Applied AI with specializations model.

### Justification delivered
Full sourced evidence document: IPEDS, Lightcast, CAEL, competitor programs (UTK / SNHU / WGU / Emeritus).

### Key arguments
- Degree name already in market at 5+ universities
- Specialization = proven enrollment strategy
- Three revenue streams from one course set: degree / non-credit / CE
- Lightcast 28% AI salary premium

### Key stat
CIP 30 (Multi/Interdisciplinary Studies): 123,205 degrees awarded nationally in 2023, +4.64% YoY, 1.01M in workforce. BS in Applied AI = employment-focused next-gen version of interdisciplinary studies.

### Status
Kennon called Allan Mar 13, surfaced justification + interdisciplinary enrollment proof points in real time.

## iDesign Partnership (Khan U vendor)
Paxton Riter (CEO) + Whitney Kilgore (CAO) -- both AP alumni with Kennon, peer dynamic.

### Context
iDesign was the first to offer unbundled fee-for-service OPM (no revenue share). 47-slide deck evaluated.

### Decision
- Buy: Build ($17.5K/course) + Align + ID services + Discovery
- Decline: OPX / marketing / enrollment

### Strategic carrot
Align + Futurenav integration = closed-loop curriculum-to-assessment.

### Approach
Reframe as partner. Test Whitney on AI-native pedagogy. Defer pricing.

## Employer Engagement (Kennon, 2026-05-13)
KTI employer engagement must produce two distinct artifacts:

1. **Skill audit** — what skills the employer's roles require. Feeds curriculum (what we teach).
2. **Task audit** — what tasks workers actually perform in those roles. Feeds simulation and project design (what experiences we construct inside the program).

Design principle: learners should encounter experiences and projects that reflect the reality of their future employment. Tasks, not skills, are the unit that maps to authentic learning experiences. Skills get composed inside tasks — designing from skills alone risks abstract coursework; designing from tasks produces work that looks like the job.

Implication for employer conversations: we are not just asking "what skills do you need?" We are asking "walk us through a week in the life of this role — what does the person actually do, decide, build, write, and ship?" Both audits run in parallel.

## JA Worldwide Partnership (Kennon, 2026-05-19)

Kennon met with JA Worldwide leadership. Four asks/offers established as ecosystem partnership:

1. **"TOEFL for Entrepreneurship"** — co-build with ETS as a credentialed assessment for entrepreneurial skills. Embed as a KTI certification/specialization.
2. **Employer organizing** — JA helps convene employers to validate the KTI skills framework. Distribution and legitimacy through JA's existing employer network.
3. **Fundraising support** — JA helps raise money for KTI.
4. **Ecosystem partner** — formal positioning of JA as part of the KTI ecosystem (alongside Khan Academy, TED, ETS, Linux Foundation).

### Strategic significance
- **TOEFL-for-Entrepreneurship is a credential franchise.** ETS owns TOEFL globally; replicating that brand structure for entrepreneurship is a defensible, monetizable signal layer that lives inside KTI but also stands alone (employer L&D, ed channels, international markets).
- **JA's global footprint** (100+ countries, millions of students annually) is a distribution asset Khan Academy and TED don't fully cover — particularly in international and youth-entrepreneurship segments.
- **Skills-framework validation through JA's employer network** strengthens the legitimacy story for KTI degree design and complements Allan Fisher's marketability defense.
- **Adds a third credential franchise to the KTI stack:** Certify.ai (AI fluency) + KTI degree (applied intelligence) + JA/ETS entrepreneurship cert. Each is independently marketable and stacks into the degree.

### Open questions / next steps
- Who owns the entrepreneurship credential IP and revenue split (ETS / JA / KTI)?
- Does it become a required vs. optional specialization within KTI?
- What's JA's leadership commitment level — formal MOU vs. early exploration?
- Fundraising mechanics: does JA help with KTI direct fundraise or with a separate entrepreneurship-credential vehicle?
- How does this interact with existing KTI ecosystem partners (Khan Academy, TED, Linux Foundation) — any IP or branding conflicts?
