# ETS Contacts & Relationships

## ETS Leadership
- **Amit Sevak** -- CEO
- **Marc McDonald** -- Chief of Staff to CEO. `mmcdonald@ets.org`, +1-202-457-8689
- **Jeff Melnick** -- CFO. Deal structure conversations.
- **Vince Dean** -- Praxis lead. Proposed distribution partner for Certify.ai.
- **Steve** -- AI capabilities lead (last name unknown). In DC Wed Mar 26.
- **Emal, Janet, Shruti** -- participated in Certify.ai discussions (last names unknown)

## ETS Applied Intelligence Team
- **Kennon** -- Managing Director
- **Michael Chasen** -- Co-Founder & Vice Chairman of Certify.ai (capital raises + IR)

## External / Government

### Nick Moore -- National Skill Audit
- **Nick Moore** -- Acting Assistant Secretary, OCTAE (US Department of Education)
- Previously: Director, Governor Kay Ivey's Office of Education and Workforce Transformation (Alabama). Helped launch Alabama Talent Triad.
- OCTAE mandate: national CTE, adult learning, workforce readiness
- Working with Kennon on the **national skill audit** concept -- bridges skills genome thesis, NTE architecture, readiness systems theory to federal workforce policy
- Significant federal relationship bridging workforce policy, measurement infrastructure, talent intelligence architecture

## Khan University vendor
- **Allan Fisher** -- consultant (degree design). Former Sr Director of Academics at Emeritus, former Associate Dean at CMU SCS, co-author "Unlocking the Clubhouse."
- **Paxton Riter** -- CEO of iDesign. AP alumni with Kennon.
- **Whitney Kilgore** -- CAO of iDesign. AP alumni with Kennon.

## Pending LinkedIn Responses
- **Mohamed El Badrawy**
- **Morgan McKenney**
- **Kristen Mitchell** -- suggested podcast idea; recommended network accelerator frame; no decision yet

## Common App Thesis (Mar 2026)
Kennon wrote strategic piece for **Rajeev Agarwal** on Common App as entry point for ETS full-stack talent intelligence. NOT a live project -- conceptual / strategic exploration.

Three principles:
1. Gating = limited seats + wrong-choice risk
2. Incomplete skill info
3. Resulting systemic inefficiency

Economics: 10-15% efficiency gain ≈ ~$1T GDP recapture. 8-10x lifetime monetization per individual.

Pipeline: K-12 (guidance counselors, readiness research) → HE (5-layer recommendation stack, flipped market) → Workforce (sourcing, screening, talent management).

Consent-first flipped marketplace: non-PII matching, employers compete on offer quality, talent controls data release. Data models as global product (high-margin, recurring).

Common App is one entry strategy; others: TOEFL pools, institutional Futurenav contracts, JFF, NTE/Richmond MVP.

Key people: Rajeev (recipient), "Ken" (referenced).
