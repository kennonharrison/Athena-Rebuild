# InsightStack + National Talent Exchange

Full deck analyzed Feb 2024 (17 slides, PDF + images extracted). Concept doc: `ets-skills/national-talent-exchange/concept.md`.

## Five-layer InsightStack
1. Direct Assessment
2. Skill Extraction (Gen-AI)
3. Skills Transcript
4. Insight Generation
5. AI-Enabled Scale

## Core play
National skills liquidity system: ETS as trusted intermediary, single-blind matching, fit scores replace resumes. Disintermediation against LinkedIn / Indeed / Handshake ($30B+ market).

## Richmond Metro MVP
- **Institutions:** Reynolds CC + VCU + MSI
- **Employers:** Capital One + VCU Health + VA state gov

## Student UX concept
"Tinder for Opportunity" -- card-based swipe, fit scores, skill gap coaching, single-blind mutual matching.

## Design principles
- **Consent-first:** No data shared with any talent consumer without individual's express consent. Design principle, not feature.
- **Revenue model:** 100% employer-funded per-hire. Talent, institutions, government always free.

## Products in the stack
- **Futurenav Edge** -- existing durable skills assessment, 24 subskills, proven for entry-level hiring fit. Skillprint = output.
- **Futurenav Compass** -- higher-ed version, piloting at Cal State + Brandeis (Sep 2025)
- **WPR (Workforce Partnerships Richmond)** -- B-corp, local GTM entity for Richmond MSA. `ets-skills/national-talent-exchange/wpr.md`
- **ProFound** -- talent intelligence platform brand. Aggregated Skillprint → skill-gap analysis + talent pool visibility.
- **Skill Audit** -- consultative service, holistic job analysis leveled against KPIs. Volume-discounted. Employer retains royalty-free perpetual license to data.
- **SkillSpark GPT** -- free top-of-funnel ChatGPT GPT. `ets-skills/national-talent-exchange/gpt-spec.md`

## Funding angles
IBM Impact Accelerator, GO Virginia / VEDP, NSF, Virginia DHRM.

## IBM Impact Accelerator
- RFP: https://www.ibm.com/campaign/impact-accelerator-rfp
- Two-year program, no cost, IBM provides tech + expertise
- Two tracks: ETS direct application AND Norwood Creek via institutional partner
- Companion report: "Responsible AI for Social Impact" (IBM x NationSwell) -- analyzed, saved to `research/`
- Strong ETS alignment across all three report framework elements

## Portfolio components
ASP, Certify.ai, Khan U, NIDCM are all components of this architecture.
