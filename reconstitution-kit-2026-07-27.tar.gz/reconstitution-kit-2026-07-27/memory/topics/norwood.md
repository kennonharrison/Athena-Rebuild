# Norwood

## Norwood House
Historic preservation project. Priorities: HVAC, rewire, replumb.

**Constraint:** 2017 conservation easement restricts commercial use (killed the executive retreat model on Feb 13 2026 -- regen ag is the path now).

Docs:
- `norwood-creek/house-infrastructure-summary.md`
- `norwood-creek/legal/`

## Norwood Creek (Regen Ag)
Business plan: 9 revenue streams, ~$3M revenue at Year 5, $5M CapEx. **Not** exit-oriented. Long-term self-sustaining value engine for family, future generations, Powhatan community.

Strategy docs: `norwood-creek/strategy/`

## Bob Waring
Spoke at length Mar 6. Visited Norwood ~Mar 15-16 to walk the property.

Status: helpful and interested, but relationship is early. **Not ready for formal partnership pitch.**

Approach: docs retooled to be general-purpose (not Bob-specific). Let him self-select into the vision rather than position him into it.

Briefs (both in Gmail drafts):
- "The Operation" -- `norwood-creek/norwood-creek-operation-brief.md`
- "The Long Vision" -- `norwood-creek/norwood-creek-vision-brief.md`

Old one-pager: `norwood-creek/one-pager-bob-waring.md`

Full dossier + network analysis: `norwood-creek/contacts/`

## Regen Ag Priority Contacts
- **Eric S. Bendfeldt, PhD** -- ebendfel@vt.edu -- VT Cooperative Extension, Sr Extension Specialist, Food Systems
- **John L. Few IV** -- johnf93@vt.edu -- VCE Powhatan County, Assoc Extension Agent, Ag & Natural Resources
- **Agatha Brinkley** -- agatha@commongrainalliance.org -- ED, Common Grain Alliance
- **Pete Sisti** -- pete@grgrains.com -- Grassland Farm, Powhatan County
- **Anthony Beery** -- anthony@beeryfarms.com -- Beery Farms, VA No-Till Alliance mentor
- **Rob Waring** -- brandonfarms3012@gmail.com -- Brandon Farms, VA No-Till Alliance mentor
- **C.J. Isbell** -- keenbellfarm@gmail.com -- Keenbell Farm, Rockville VA
- **J.B. Daniel** -- j.b.daniel@va.usda.gov -- USDA
- **Matt Royer** -- Penn State

## House/Legal Professional Contacts
Adams Sutphin, Sadler and Whitehead, David Lionberger, BEC (becpas.com) -- all Norwood house/legal.

## Grants (status in memory/ daily logs)
- **VDACS AFID Infrastructure Grant** -- open Mar 16 - Apr 30, 2026. Max $50K, 1:1 locality match, Powhatan County must apply. Contact: Joyce Blankenship, 804.786.1906
- **USDA VAPG** -- deadline April 22, 2026
- **VAFAIRS** -- deadline April 16, 2026
- **Southern SARE Producer Grant** -- deadline May 8, 2026
